/* Football CEO — Transfers & Contracts module
   Extracted from game.js without intended gameplay changes.

   Owns:
   - contract renewals
   - wage demands / acceptance
   - transfer & loan listing
   - manager squad-management requests
   - transfer-related stakeholder hooks

   This file is loaded before game.js, so these functions are available globally.
*/

function ensureContractState(){
  ensureTransferMarketState();
  if(!state.playerContracts) state.playerContracts={};
  if(!state.playerListStatus) state.playerListStatus={};
  if(!state.managerRequests) state.managerRequests=[];
  if(!state.managerRequestCooldowns) state.managerRequestCooldowns={};
  if(!state.managerRequestRejections) state.managerRequestRejections={};
  if(!state.managerRoleFulfilledUntil) state.managerRoleFulfilledUntil={};
  if(!state.managerTactics) state.managerTactics={};
  squad(state.club).forEach(p=>{
    if(!state.playerContracts[p.id]){
      state.playerContracts[p.id]={
        wage:p.wage||0,
        endYear:p.contract||2026
      };
    }
    if(!state.playerListStatus[p.id]) state.playerListStatus[p.id]="None";
  });
}

function playerContractDemand(p){
  ensureContractState();

  const current=state.playerContracts[p.id] || {wage:p.wage||0,endYear:p.contract||2026};
  const currentWage=Math.max(1000,current.wage||p.wage||1000);
  const morale=state.playerMorale?.[p.id]||"Content";
  const stats=state.playerStats?.[p.id]||{appearances:0,goals:0};

  // 1) Rating / status premium.
  // Low-rated squad players generally ask for modest rises;
  // elite players can command significantly more.
  let ratingFactor=1;
  if(p.overall>=88) ratingFactor=1.20;
  else if(p.overall>=85) ratingFactor=1.15;
  else if(p.overall>=82) ratingFactor=1.11;
  else if(p.overall>=79) ratingFactor=1.08;
  else if(p.overall>=76) ratingFactor=1.06;
  else if(p.overall>=73) ratingFactor=1.04;
  else ratingFactor=1.02;

  // 2) Morale.
  // Happy players are easier to renew; unhappy players demand a premium.
  let moraleFactor=1;
  if(morale==="Happy") moraleFactor=0.96;
  else if(morale==="Content") moraleFactor=1.00;
  else if(morale==="Unhappy") moraleFactor=1.10;
  else if(morale==="Wants to leave") moraleFactor=1.22;

  // 3) Individual season performance.
  // At GW0 this is neutral. Once games are played, regular starters and
  // productive attackers earn stronger negotiating leverage.
  let performanceFactor=1;
  if(state.week>0){
    const appearanceRate=stats.appearances/Math.max(1,state.week);
    const goalRate=stats.goals/Math.max(1,stats.appearances);

    if(appearanceRate>=0.85) performanceFactor+=0.04;
    else if(appearanceRate<=0.35) performanceFactor-=0.03;

    const pos=String(p.positions||"");
    const attacking=pos.includes("ST")||pos.includes("CF")||pos.includes("LW")||pos.includes("RW")||
                    pos.includes("CAM")||pos.includes("LM")||pos.includes("RM");

    if(attacking){
      if(goalRate>=0.60) performanceFactor+=0.10;
      else if(goalRate>=0.35) performanceFactor+=0.06;
      else if(goalRate>=0.18) performanceFactor+=0.03;
      else if(stats.appearances>=8 && goalRate<0.08) performanceFactor-=0.03;
    }else{
      // Non-attackers gain leverage mainly from being regular starters.
      if(appearanceRate>=0.90 && stats.appearances>=6) performanceFactor+=0.03;
    }
  }

  // 4) Contract leverage.
  // Players close to expiry know the club has less control.
  const yearsLeft=Math.max(0,(current.endYear||currentContractSeasonEndYear())-currentSeasonStartYear());
  let contractFactor=1;
  if(yearsLeft<=1) contractFactor=1.05;
  else if(yearsLeft>=4) contractFactor=0.98;

  let demand=currentWage*ratingFactor*moraleFactor*performanceFactor*contractFactor;

  // Nobody asks for a pay cut in a normal renewal unless they are already
  // substantially overpaid relative to their level.
  const floor=currentWage*(p.overall<=72 ? 0.98 : 1.01);
  demand=Math.max(floor,demand);

  // Round naturally by salary band rather than forcing everyone to the same step.
  let step=1000;
  if(demand>=100000) step=5000;
  else if(demand>=50000) step=2500;

  return Math.round(demand/step)*step;
}

function playerContractDemandBreakdown(p){
  ensureContractState();
  const current=state.playerContracts[p.id] || {wage:p.wage||0,endYear:p.contract||2026};
  const stats=state.playerStats?.[p.id]||{appearances:0,goals:0};
  const morale=state.playerMorale?.[p.id]||"Content";
  const demand=playerContractDemand(p);

  const reasons=[];
  reasons.push(`Current wage ${money(current.wage||p.wage||0)}/wk`);
  reasons.push(`${p.overall} OVR`);
  reasons.push(`${morale.toLowerCase()} morale`);

  if(state.week>0){
    reasons.push(`${stats.appearances} apps`);
    if(stats.goals>0) reasons.push(`${stats.goals} goals`);
  }

  return {demand,reasons};
}

function contractAcceptanceChance(p,offerWage,years){
  const demand=playerContractDemand(p);
  let chance=0.40 + (offerWage/demand-1)*1.4;
  if(years>=4 && p.age<=28) chance+=0.08;
  if(years>=4 && p.age>=31) chance-=0.06;
  const morale=state.playerMorale?.[p.id]||"Content";
  if(morale==="Happy") chance+=0.08;
  if(morale==="Unhappy") chance-=0.10;
  if(morale==="Wants to leave") chance-=0.20;
  return clamp(chance,0.05,0.95);
}

function setPlayerListStatus(id,status,source="CEO"){
  ensureContractState();
  state.playerListStatus[id]=status;
  const p=DB.players.find(x=>String(x.id)===String(id));
  if(!p) return;
  if(status==="Transfer"){
    state.playerMorale[id]=state.playerMorale[id]==="Happy"?"Content":state.playerMorale[id];
    addNews(`${p.name} has been added to the transfer list${source==="Manager"?" at the manager's request":""}.`);
  }else if(status==="Loan"){
    addNews(`${p.name} has been added to the loan list${source==="Manager"?" at the manager's request":""}.`);
  }else{
    addNews(`${p.name} has been removed from all outgoing lists.`);
  }
}


function primaryRecruitmentGroup(p){
  const tokens=playerPositionTokens(p);
  if(tokens.includes("GK")) return "GK";
  if(tokens.includes("RB")||tokens.includes("RWB")) return "RB";
  if(tokens.includes("LB")||tokens.includes("LWB")) return "LB";
  if(tokens.includes("CB")) return "CB";
  if(tokens.includes("CDM")||tokens.includes("DM")) return "DM";
  if(tokens.includes("CAM")||tokens.includes("AM")) return "AM";
  if(tokens.includes("CM")) return "CM";
  if(tokens.includes("RW")||tokens.includes("RM")) return "RW";
  if(tokens.includes("LW")||tokens.includes("LM")) return "LW";
  if(tokens.includes("ST")||tokens.includes("CF")) return "ST";
  return null;
}

function registerManagerSquadVacancy(p,oldClub){
  if(oldClub!==state.club || !p) return;
  ensureTransferMarketState();

  const group=primaryRecruitmentGroup(p);
  if(!group) return;

  const before=clubSquadPlayers(state.club)
    .filter(x=>playsPositionGroup(x,group))
    .sort((a,b)=>(b.overall||0)-(a.overall||0));

  const wasRank=before.findIndex(x=>String(x.id)===String(p.id));

  let requestedRole="backup";
  if(wasRank===0) requestedRole="starter";
  else if(wasRank===1) requestedRole="competition";

  const clubRep=byClub(state.club)?.reputation||72;
  const firstTeamThreshold=clamp(Math.round(65+(clubRep-65)*0.42),70,84);
  if((p.overall||0)<firstTeamThreshold && requestedRole!=="backup") return;

  if(state.managerRoleFulfilledUntil){
    delete state.managerRoleFulfilledUntil[`${group}-${requestedRole}`];
  }

  const existing=state.managerSquadVacancies.find(v=>v.position===group && !v.filled);
  if(existing){
    existing.priority=Math.max(existing.priority||0,p.overall||0);
    existing.week=state.week;
    existing.role=requestedRole;
  }else{
    state.managerSquadVacancies.push({
      position:group,
      role:requestedRole,
      soldPlayerId:p.id,
      soldPlayerName:p.name,
      soldOverall:p.overall||0,
      week:state.week,
      filled:false,
      priority:p.overall||0
    });
  }

  if(typeof scheduleManagerReassessment==="function") scheduleManagerReassessment(1);
}


function managerPositionStandard(position){
  const players=clubSquadPlayers(state.club)
    .filter(p=>playsPositionGroup(p,position))
    .sort((a,b)=>b.overall-a.overall);
  const starter=players[0]?.overall||68;
  const second=players[1]?.overall||Math.max(62,starter-8);
  const clubRep=byClub(state.club)?.reputation||70;

  // The manager's expected first-team standard is anchored to BOTH
  // current squad quality and club reputation.
  const reputationStandard=clamp(Math.round(68+(clubRep-70)*0.42),70,87);
  return {
    starter,
    second,
    expectedStarter:Math.max(starter,reputationStandard),
    expectedDepth:Math.max(second,reputationStandard-6)
  };
}

function realisticManagerTargetPool(position,limit=30){
  const club=state.club;
  const userRep=byClub(club)?.reputation||70;
  const standard=managerPositionStandard(position);

  return DB.players
    .filter(p=>p.club!==club && p.club!=="Free Agent" && playsPositionGroup(p,position))
    .map(p=>{
      const sellingRep=byClub(p.club)?.reputation||68;
      const asking=estimatedAskingPrice(p,club);
      const interest=playerInterestScore(p,club);
      const overall=p.overall||0;
      const potential=p.potential||overall;

      // Hard realism filters.
      const eliteBlock=(overall>=88 && userRep<88 && sellingRep>=userRep+2);
      const prestigeBlock=(sellingRep>=userRep+8 && interest<62);
      const interestBlock=(interest<38);
      const affordabilityCeiling=Math.max((state.budget||0)*1.20,30_000_000);
      const budgetBlock=asking>affordabilityCeiling;

      // A normal first-team recommendation cannot be dramatically below
      // the club's current standard.
      const qualityBlock=overall<standard.expectedStarter-5 && potential<standard.expectedStarter+1;

      return {
        player:p,asking,interest,overall,potential,sellingRep,
        attainable:!eliteBlock&&!prestigeBlock&&!interestBlock&&!budgetBlock&&!qualityBlock
      };
    })
    .filter(x=>x.attainable)
    .sort((a,b)=>{
      const sa=(a.overall*2.2)+(a.interest*.22)+(a.potential*.30)-(a.asking/1_000_000*.10);
      const sb=(b.overall*2.2)+(b.interest*.22)+(b.potential*.30)-(b.asking/1_000_000*.10);
      return sb-sa;
    })
    .slice(0,limit);
}

function buildManagerShortlist(position,role="starter"){
  const pool=realisticManagerTargetPool(position,40);
  if(!pool.length) return [];

  const need=evaluateSquadNeeds(state.club).find(n=>n.position===position);
  const standards=need?.standards || managerPositionStandard(position);
  const currentStarter=need?.starter||standards.starter||70;

  const roleFloor =
    role==="starter" ? Math.max(currentStarter-1,standards.starter-2) :
    role==="competition" ? Math.max(standards.competition-3,currentStarter-5) :
    role==="prospect" ? 58 :
    Math.max(standards.backup-4,64);

  const roleCeiling =
    role==="prospect" ? Math.max(72,currentStarter-5) :
    role==="backup" ? Math.max(roleFloor+8,currentStarter-2) :
    role==="competition" ? Math.max(roleFloor+6,currentStarter+1) :
    99;

  const rolePool=pool.filter(x=>{
    const o=x.player.overall||0;
    if(role==="starter") return o>=roleFloor;
    if(role==="competition") return o>=roleFloor && o<=roleCeiling;
    if(role==="prospect"){
      const potential=x.player.potential||o;
      return x.player.age<=22 && o>=roleFloor && o<=roleCeiling && potential>=Math.max(standards.competition,currentStarter-2);
    }
    return o>=roleFloor && o<=roleCeiling;
  });

  const usable=rolePool.length?rolePool:pool;

  // Option 1: ideal for the REQUESTED ROLE, not simply best player available.
  const ideal=[...usable].sort((a,b)=>{
    const oa=a.player.overall||0, ob=b.player.overall||0;
    let scoreA=(oa*2.5)+(a.interest*.18)+(a.player.potential||oa)*.18-(a.asking/1e6*.08);
    let scoreB=(ob*2.5)+(b.interest*.18)+(b.player.potential||ob)*.18-(b.asking/1e6*.08);

    // Backups should not be overqualified; prospects are scored primarily on upside.
    if(role==="backup"){
      scoreA-=Math.max(0,oa-currentStarter+1)*1.4;
      scoreB-=Math.max(0,ob-currentStarter+1)*1.4;
    }
    if(role==="prospect"){
      scoreA+=(a.player.potential||oa)*1.5-a.player.age*1.2;
      scoreB+=(b.player.potential||ob)*1.5-b.player.age*1.2;
    }
    return scoreB-scoreA;
  })[0];

  // Option 2: cheaper alternative, still role-appropriate.
  const cheaper=usable
    .filter(x=>x.player.id!==ideal?.player.id)
    .filter(x=>x.asking<=ideal.asking*.78)
    .sort((a,b)=>{
      const oa=a.player.overall||0, ob=b.player.overall||0;
      return ((ob*2)-(b.asking/1e6*.28))-((oa*2)-(a.asking/1e6*.28));
    })[0]
    || usable.find(x=>x.player.id!==ideal?.player.id);

  // Option 3: prospect. This can sit below immediate role standard if upside is strong.
  const used=new Set([ideal?.player.id,cheaper?.player.id].filter(Boolean));
  const prospect=pool
    .filter(x=>!used.has(x.player.id))
    .filter(x=>x.player.age<=22)
    .filter(x=>(x.player.potential||x.player.overall)>=Math.max(standards.competition,currentStarter))
    .sort((a,b)=>{
      const pa=a.player.potential||a.player.overall;
      const pb=b.player.potential||b.player.overall;
      return ((pb*2.5)+(b.interest*.15)-(b.asking/1e6*.08))-((pa*2.5)+(a.interest*.15)-(a.asking/1e6*.08));
    })[0]
    || pool.find(x=>!used.has(x.player.id) && x.player.age<=23);

  const out=[];
  if(ideal) out.push({...ideal,role:role==="prospect"?"Best prospect":"Ideal target"});
  if(cheaper&&!out.some(x=>x.player.id===cheaper.player.id)) out.push({...cheaper,role:role==="prospect"?"Value prospect":"Cheaper alternative"});
  if(prospect&&!out.some(x=>x.player.id===prospect.player.id)) out.push({...prospect,role:"Young prospect"});
  return out.slice(0,3);
}

function managerShortlistForRequest(req){
  return (req.shortlist||[]).map(x=>{
    const p=DB.players.find(pl=>String(pl.id)===String(x.playerId));
    return p?{...x,player:p}:null;
  }).filter(Boolean);
}


function managerPerformanceRecruitmentPressure(){
  if(state.week<8) return 0;
  const pos=typeof clubLeaguePosition==="function"?clubLeaguePosition(state.club):10;
  const target=byClub(state.club)?.target||10;
  const gap=pos-target;

  let pressure=0;
  if(gap>=7) pressure=3;
  else if(gap>=5) pressure=2;
  else if(gap>=3) pressure=1;

  // No transfer spending while badly underperforming increases the manager's
  // sense that the squad needs reinforcement.
  const spent=state.transferFinance?.spent||0;
  if(state.week>=12 && spent<5_000_000 && gap>=4) pressure+=1;

  return pressure;
}

function maybeGenerateManagerSquadRequest(){
  ensureContractState();
  if(!state.staff?.manager) return;

  const manager=state.staff.manager;
  const sq=squad(state.club);
  const needs=evaluateSquadNeeds(state.club);
  const transferWindowOpen=isTransferWindowOpen();
  const performancePressure=managerPerformanceRecruitmentPressure();

  if(!state.managerRequestsByWeek) state.managerRequestsByWeek={};
  const weekKey=typeof currentCalendarWeekKey==="function"?currentCalendarWeekKey():String(state.week);
  const alreadyThisWeek=state.managerRequestsByWeek[weekKey]||0;
  const remainingSlots=Math.max(0,2-alreadyThisWeek);
  if(remainingSlots<=0) return;

  let options=[];

  // Explicit vacancies from sales.
  if(transferWindowOpen){
    (state.managerSquadVacancies||[]).filter(v=>!v.filled).forEach(v=>{
      const shortlist=buildManagerShortlist(v.position,v.role||"starter");
      if(shortlist.length){
        options.push({
          type:"sign",
          position:v.position,
          squadRole:v.role||"starter",
          playerId:shortlist[0].player.id,
          priority:14,
          alternatives:shortlist.slice(1).map(x=>x.player.id),
          shortlist:shortlist.map(x=>({
            playerId:x.player.id,role:x.role,asking:x.asking,interest:x.interest
          })),
          urgency:"critical",
          vacancy:true,
          reason:`A ${v.role||"starter"} replacement is needed after ${v.soldPlayerName}'s departure.`
        });
      }
    });
  }

  // Normal squad assessment.
  if(transferWindowOpen){
    needs.filter(n=>n.role!=="none").forEach(need=>{
      const shortlist=buildManagerShortlist(need.position,need.role);
      if(!shortlist.length) return;

      let priority=
        need.role==="starter" ? 10 :
        need.role==="competition" ? 7 : 4;

      if(need.score>=75) priority+=2;
      if(performancePressure>=2 && need.role!=="backup") priority+=2;

      options.push({
        type:"sign",
        position:need.position,
        squadRole:need.role,
        playerId:shortlist[0].player.id,
        priority,
        alternatives:shortlist.slice(1).map(x=>x.player.id),
        shortlist:shortlist.map(x=>({
          playerId:x.player.id,role:x.role,asking:x.asking,interest:x.interest
        })),
        urgency:need.score>=72?"critical":need.score>=50?"important":"normal",
        reason:need.reason
      });
    });
  }

  // Contract / list-management requests.
  sq.forEach(p=>{
    const c=state.playerContracts[p.id];

    const renewRejectedDay=state.managerRequestRejections?.[`renew-${p.id}`];
    const renewCooling=renewRejectedDay!=null && currentCareerDay()-renewRejectedDay<84;
    if(c && c.endYear<=currentContractSeasonEndYear() && p.overall>=78 && !renewCooling){
      options.push({type:"renew",playerId:p.id,priority:3});
    }

    if(p.age>=29 && p.overall<=74 && state.playerListStatus?.[p.id]!=="Transfer"){
      options.push({type:"transfer",playerId:p.id,priority:2});
    }
  });

  // A recently fulfilled recruitment role is suppressed for 12 weeks unless
  // a fresh explicit vacancy is created later.
  options=options.filter(o=>{
    if(o.type!=="sign") return true;
    const key=`${o.position}-${o.squadRole||"starter"}`;
    const until=state.managerRoleFulfilledUntil?.[key];
    return until==null || currentCareerDay()>=until;
  });

  // Remove duplicate open requests.
  const openRequests=state.managerRequests.filter(r=>!r.resolved);
  options=options.filter(o=>!openRequests.some(r=>{
    if(o.type==="sign"){
      return r.type==="sign" && r.position===o.position && (r.squadRole||"starter")===(o.squadRole||"starter");
    }
    return r.type===o.type && String(r.playerId)===String(o.playerId);
  }));

  const requestThreshold=managerProfileForClub(state.club).recruitmentAggression>=80 ? 22 :
    managerProfileForClub(state.club).recruitmentAggression>=65 ? 28 : 34;
  options=options.filter(o=>o.type!=="sign" || o.priority>=requestThreshold/4 || o.vacancy);

  if(!options.length) return;

  // Deterministic manager appetite: some weeks one request, some weeks two.
  // Aggressive/high-pressure situations make two more likely.
  const managerProfile=managerProfileForClub(state.club);
  let maxRequests=managerProfile.recruitmentAggression>=82 ? 2 : 1;
  const unresolvedRecruitment=openRequests.filter(r=>r.type==="sign").length;
  const majorNeeds=needs.filter(n=>n.role==="starter" && n.score>=60).length;
  const overhaulPressure=performancePressure>=2 || majorNeeds>=2 || (state.managerSquadVacancies||[]).filter(v=>!v.filled).length>=2;

  if(overhaulPressure && remainingSlots>=2){
    maxRequests=2;
  }else if(remainingSlots>=2 && Math.random()<0.28){
    maxRequests=2;
  }

  maxRequests=Math.min(maxRequests,remainingSlots);

  for(let requestIndex=0;requestIndex<maxRequests;requestIndex++){
    if(!options.length) break;

    // Prioritise starter > competition > backup when scores are comparable.
    options.sort((a,b)=>{
      const roleWeight=r=>r==="starter"?12:r==="competition"?7:r==="backup"?3:0;
      const scoreA=(a.priority||0)+roleWeight(a.squadRole);
      const scoreB=(b.priority||0)+roleWeight(b.squadRole);
      return scoreB-scoreA;
    });

    const pick=options.shift();
    const p=DB.players.find(x=>String(x.id)===String(pick.playerId));
    if(!p) continue;

    if(!state.managerRequestCooldowns) state.managerRequestCooldowns={};
    const cooldownKey=pick.type==="sign"
      ? `sign-${pick.position}-${pick.squadRole||"starter"}`
      : `${pick.type}-${p.id}`;

    const lastDay=state.managerRequestCooldowns[cooldownKey];
    if(lastDay!=null && currentCareerDay()-lastDay<14) continue;
    state.managerRequestCooldowns[cooldownKey]=currentCareerDay();

    const id="mr"+Date.now()+Math.floor(Math.random()*1000)+requestIndex;
    const req={
      id,
      type:pick.type,
      playerId:p.id,
      position:pick.position||null,
      squadRole:pick.squadRole||null,
      alternatives:pick.alternatives||[],
      shortlist:pick.shortlist||[],
      urgency:pick.urgency||null,
      reason:pick.reason||null,
      resolved:false,
      manager:manager.name
    };

    state.managerRequests.push(req);
    state.managerRequestsByWeek[weekKey]=(state.managerRequestsByWeek[weekKey]||0)+1;

    let wording;
    if(pick.type==="sign"){
      const roleLabel={
        starter:"new starting",
        competition:"new first-team competition",
        backup:"new backup",
        prospect:"young prospect"
      }[pick.squadRole] || "new";

      wording=`${manager.name} wants a ${roleLabel} ${positionLabel(pick.position)} for the ${managerFormationForClub(state.club)}. A three-player shortlist is ready for review.${pick.reason?` ${pick.reason}`:""}`;
    }else if(pick.type==="renew"){
      wording=`${manager.name} wants the club to open contract talks with ${p.name}.`;
    }else if(pick.type==="transfer"){
      wording=`${manager.name} recommends placing ${p.name} on the transfer list.`;
    }else{
      wording=`${manager.name} recommends making ${p.name} available for loan.`;
    }

    state.news.unshift({week:state.week,date:currentGameDateISO(),text:wording,requestId:id});

    // Prevent a second request for the exact same positional role in same week.
    options=options.filter(o=>!(
      o.type==="sign" &&
      o.position===pick.position &&
      (o.squadRole||"starter")===(pick.squadRole||"starter")
    ));
  }
}
function resolveManagerRequest(id,accepted){
  ensureContractState();
  const req=state.managerRequests.find(r=>r.id===id);
  if(!req || req.resolved) return;
  req.resolved=true;
  const p=DB.players.find(x=>x.id===req.playerId);

  if(accepted){
    if(req.type!=="sign") state.managerBacking=clamp((state.managerBacking||70)+3,0,100);
    if(req.type==="transfer") setPlayerListStatus(p.id,"Transfer","Manager");
    
    else if(req.type==="sign"){
      req.resolved=false;
      openManagerShortlist(req.id);
      saveGame(false);
      renderInbox();
      return;
    }else{
      addNews(`You agreed with ${req.manager} to begin contract talks with ${p.name}.`);
      openPlayerProfile(p.id);
      q("contractNegotiation")?.classList.remove("hide");
    }
  }else{
    if(req.type==="renew"){
      if(!state.managerRequestRejections) state.managerRequestRejections={};
      state.managerRequestRejections[`renew-${req.playerId}`]=currentCareerDay();
    }
    if(req.type!=="sign") state.managerBacking=clamp((state.managerBacking||70)-3,0,100);
    if(req.type==="sign") recordManagerTransferChoice(false);
    addNews(`You rejected ${req.manager}'s recommendation regarding ${p.name}.`);
  }

  saveGame(false);
  renderInbox();
  renderDashboard();
}

function recordStarSale(player,fee,fairValue,yearsAtClub=1){
  const topRatings=squad(state.club).map(p=>p.overall).sort((a,b)=>b-a).slice(0,5);
  const isStar=topRatings.includes(player.overall);
  if(!isStar) return;
  let fanHit=-3;
  if(yearsAtClub>=4) fanHit-=2;
  if(fee<fairValue*0.9) fanHit-=3;
  else if(fee>=fairValue*1.15) fanHit+=2;

  if(typeof stakeholderChange==="function"){
    stakeholderChange("fans",fanHit,`Sale of star player ${player.name}`,{notify:true});
    if(fee>=fairValue*1.15) stakeholderChange("owners",1,`Strong fee received for ${player.name}`,{notify:true});
    else if(fee<fairValue*0.9) stakeholderChange("owners",-2,`Poor value received for ${player.name}`,{notify:true});
  }else{
    if(!state.transferSentiment) state.transferSentiment={fans:[],owners:[],players:[],manager:[]};
    state.transferSentiment.fans.push({label:`Sale of star player ${player.name}`,value:fanHit});
  }
}

function recordMarqueeSigning(player){
  if(typeof stakeholderDecision==="function"){
    stakeholderDecision({fans:5,players:1},`Marquee signing: ${player.name}`,{notify:true});
  }else{
    if(!state.transferSentiment) state.transferSentiment={fans:[],owners:[],players:[],manager:[]};
    state.transferSentiment.fans.push({label:`Marquee signing: ${player.name}`,value:5});
  }
}

function recordManagerTransferChoice(backedManager){
  state.managerBacking=clamp((state.managerBacking??70)+(backedManager?8:-6),0,100);
  if(typeof stakeholderChange==="function"){
    stakeholderChange(
      "manager",
      backedManager?4:-4,
      backedManager?"Backed manager's transfer target":"Rejected manager's preferred target",
      {notify:true}
    );
  }else{
    if(!state.transferSentiment) state.transferSentiment={fans:[],owners:[],players:[],manager:[]};
    state.transferSentiment.manager.push({label:backedManager?"Backed manager's transfer target":"Rejected manager's preferred target",value:backedManager?4:-4});
  }
}

function beginContractNegotiation(id){
  ensureContractState();
  const p=DB.players.find(x=>String(x.id)===String(id));
  if(!p) return;
  const current=state.playerContracts[p.id];
  const breakdown=playerContractDemandBreakdown(p);
  const demand=breakdown.demand;
  q("contractWageInput").value=Math.max(current.wage,demand);
  q("contractYearsInput").value="3";
  q("contractDemandText").textContent=`Agent expectation: around ${money(demand)}/wk • Based on ${breakdown.reasons.join(" • ")}.`;
  q("contractNegotiation").dataset.playerId=p.id;
  q("contractNegotiation").classList.remove("hide");
}

function submitContractOffer(){
  const id=q("contractNegotiation")?.dataset.playerId;
  const p=DB.players.find(x=>String(x.id)===String(id));
  if(!p) return;
  const wage=Number(q("contractWageInput").value||0);
  const years=Number(q("contractYearsInput").value||1);
  const chance=contractAcceptanceChance(p,wage,years);

  if(Math.random()<chance){
    state.playerContracts[p.id]={
      wage,
      endYear:currentSeasonStartYear()+years
    };
    state.playerMorale[p.id]=state.playerMorale[p.id]==="Wants to leave"?"Unhappy":"Happy";
    addNews(`${p.name} has signed a new ${years}-year contract worth ${money(wage)}/week.`);
    q("contractNegotiation").classList.add("hide");
    saveGame(false);
    openPlayerProfile(p.id);
    renderSquad();
    renderFinances();
  }else{
    addNews(`${p.name}'s representatives rejected your contract offer.`);
    const revised=playerContractDemandBreakdown(p);
    q("contractDemandText").textContent=`Offer rejected. The player is looking for something closer to ${money(revised.demand)}/week • ${revised.reasons.join(" • ")}.`;
  }
}

function toggleTransferList(id){
  ensureContractState();
  const current=state.playerListStatus[id]||"None";
  setPlayerListStatus(id,current==="Transfer"?"None":"Transfer");
  saveGame(false);
  openPlayerProfile(id);
  renderSquad();
}

function toggleLoanList(id){
  ensureContractState();
  const current=state.playerListStatus[id]||"None";
  setPlayerListStatus(id,current==="Loan"?"None":"Loan");
  saveGame(false);
  openPlayerProfile(id);
  renderSquad();
}




/* --------------------------------------------------------------------------
   AI club finance engine — v0.14
   -------------------------------------------------------------------------- */

function deterministicClubNumber(club,salt="finance"){
  const str=String(club)+salt;
  let h=2166136261;
  for(let i=0;i<str.length;i++) h=Math.imul(h^str.charCodeAt(i),16777619);
  return ((h>>>0)%10000)/9999;
}

function estimateClubFootballRevenue(club){
  const c=byClub(club);
  const rep=c?.reputation||70;
  const ratings=DB.players.filter(p=>p.club===club).map(p=>p.overall).sort((a,b)=>b-a).slice(0,16);
  const squadStrength=ratings.length?ratings.reduce((x,y)=>x+y,0)/ratings.length:70;
  const variance=0.92+deterministicClubNumber(club,"revenue")*0.16;
  const base=55_000_000;
  const reputationValue=Math.max(0,rep-65)*8_250_000;
  const strengthValue=Math.max(0,squadStrength-70)*3_000_000;
  let finishFactor=1;
  if(club===state?.club && state?.careerHistory?.seasons?.length){ const last=state.careerHistory.seasons[state.careerHistory.seasons.length-1]; finishFactor=last.leagueFinish<=4?1.12:last.leagueFinish<=7?1.07:last.leagueFinish<=12?1:last.leagueFinish<=16?.95:.90; }
  return Math.round((base+reputationValue+strengthValue)*variance*finishFactor/1_000_000)*1_000_000;
}

function currentClubWeeklyPlayerWages(club){
  return DB.players.filter(p=>p.club===club).reduce((sum,p)=>{
    if(club===state.club) return sum+(state.playerContracts?.[p.id]?.wage??p.wage??0);
    return sum+(p.wage||0);
  },0);
}

function aiOwnerProfile(club){
  const roll=deterministicClubNumber(club,"owner");
  const rep=byClub(club)?.reputation||70;
  if(roll>0.82) return {type:"Ambitious",reinvestment:0.95,budgetAggression:1.15,scrComfort:0.97};
  if(roll<0.18) return {type:"Conservative",reinvestment:0.70,budgetAggression:0.82,scrComfort:0.86};
  if(rep>=88) return {type:"Elite",reinvestment:0.90,budgetAggression:1.08,scrComfort:0.94};
  return {type:"Balanced",reinvestment:0.82,budgetAggression:1.00,scrComfort:0.90};
}

function initialAITransferBudget(club,revenue){
  const c=byClub(club);
  const owner=aiOwnerProfile(club);
  const configured=c?.transferBudget||0;
  const revenueFloor=revenue*(0.10+Math.max(0,(c?.reputation||70)-70)*0.0025);
  return Math.round(Math.max(configured,revenueFloor)*owner.budgetAggression/250000)*250000;
}

function initialAIWageBudget(club,revenue){
  const c=byClub(club);
  if(c?.wageBudget) return c.wageBudget;
  return Math.round((revenue*0.48/52)/1000)*1000;
}

function ensureAIClubFinances(){
  if(!state) return;
  if(!state.aiClubFinances) state.aiClubFinances={};

  DB.clubs.forEach(c=>{
    if(c.name===state.club) return;

    if(!state.aiClubFinances[c.name]){
      const revenue=estimateClubFootballRevenue(c.name);
      const liveWages=currentClubWeeklyPlayerWages(c.name);
      const owner=aiOwnerProfile(c.name);

      state.aiClubFinances[c.name]={
        club:c.name,
        footballRevenue:revenue,
        transferBudget:initialAITransferBudget(c.name,revenue),
        wageBudget:Math.max(initialAIWageBudget(c.name,revenue),Math.round(liveWages*1.08/1000)*1000),
        weeklyWages:liveWages,
        transferSpent:0,
        transferReceived:0,
        ownerType:owner.type,
        reinvestmentRate:owner.reinvestment,
        scrComfort:owner.scrComfort
      };
    }else{
      state.aiClubFinances[c.name].weeklyWages=currentClubWeeklyPlayerWages(c.name);
    }
  });
}

function aiFinance(club){
  ensureAIClubFinances();
  return state.aiClubFinances?.[club]||null;
}

function aiNetTransferSpend(club){
  const f=aiFinance(club);
  return f?(f.transferSpent||0)-(f.transferReceived||0):0;
}

function aiProjectedSquadCost(club,extraFee=0,extraWeeklyWage=0){
  const f=aiFinance(club);
  if(!f) return Infinity;

  const annualWages=(f.weeklyWages+extraWeeklyWage)*52;

  // Casual-player abstraction of transfer cost for SCR.
  // No amortisation/book-value concepts are exposed in the game.
  const positiveNetSpend=Math.max(0,aiNetTransferSpend(club)+extraFee);
  const transferCommitment=positiveNetSpend*0.20;

  return annualWages+transferCommitment;
}

function aiSCRRatio(club,extraFee=0,extraWeeklyWage=0){
  const f=aiFinance(club);
  if(!f || !f.footballRevenue) return 9.99;
  return aiProjectedSquadCost(club,extraFee,extraWeeklyWage)/f.footballRevenue;
}

function aiSCRStatus(club,extraFee=0,extraWeeklyWage=0){
  const ratio=aiSCRRatio(club,extraFee,extraWeeklyWage);
  if(ratio<=0.85) return "Green";
  if(ratio<=1.15) return "Amber";
  return "Red";
}

function aiSCRHeadroom(club){
  const f=aiFinance(club);
  if(!f) return 0;
  return Math.max(0,f.footballRevenue*0.85-aiProjectedSquadCost(club));
}

function aiCanAffordTransfer(club,fee,weeklyWage){
  const f=aiFinance(club);
  if(!f) return {ok:false,reason:"No finance data"};

  if(f.transferBudget<fee) return {ok:false,reason:"Transfer budget"};
  if(f.weeklyWages+weeklyWage>f.wageBudget) return {ok:false,reason:"Wage budget"};

  const projectedRatio=aiSCRRatio(club,fee,weeklyWage);
  if(projectedRatio>1.15) return {ok:false,reason:"SCR red zone"};
  if(projectedRatio>f.scrComfort) return {ok:false,reason:"Owner SCR tolerance"};

  return {ok:true,reason:"Affordable",projectedSCR:projectedRatio};
}

function aiFinancialPressure(club){
  const f=aiFinance(club);
  if(!f) return "Unknown";

  const scr=aiSCRRatio(club);
  const wageUse=f.weeklyWages/Math.max(1,f.wageBudget);
  const startingBudget=Math.max(1,initialAITransferBudget(club,f.footballRevenue));
  const budgetLeft=f.transferBudget/startingBudget;

  if(scr>1.05 || wageUse>1.00) return "Critical";
  if(scr>0.92 || wageUse>0.95 || budgetLeft<0.10) return "Pressure";
  if(scr>0.82 || wageUse>0.88 || budgetLeft<0.25) return "Watch";
  return "Comfortable";
}

function aiSaleWillingnessModifier(club){
  const pressure=aiFinancialPressure(club);
  if(pressure==="Critical") return 0.90;
  if(pressure==="Pressure") return 0.95;
  if(pressure==="Watch") return 0.99;
  return 1.04;
}

function applyAITransferPurchase(club,fee,weeklyWage){
  const f=aiFinance(club);
  if(!f) return;
  f.transferBudget=Math.max(0,f.transferBudget-fee);
  f.transferSpent+=fee;
  f.weeklyWages+=weeklyWage;
}

function applyAITransferSale(club,fee,weeklyWageSaved=0){
  const f=aiFinance(club);
  if(!f) return;
  f.transferReceived+=fee;
  f.transferBudget+=fee*f.reinvestmentRate;
  f.weeklyWages=Math.max(0,f.weeklyWages-weeklyWageSaved);
}

function refreshAIClubFinance(club){
  const f=aiFinance(club);
  if(f) f.weeklyWages=currentClubWeeklyPlayerWages(club);
}


function userFootballRevenue(){
  return estimateClubFootballRevenue(state.club);
}

function userProjectedSquadCost(){
  const sq=DB.players.filter(p=>p.club===state.club);
  const weeklyPlayerWages=sq.reduce((sum,p)=>sum+(state.playerContracts?.[p.id]?.wage??p.wage??0),0);
  const managerWage=state.staff?.manager?.wage||0;
  const annualFootballWages=(weeklyPlayerWages+managerWage)*52;
  const netSpend=Math.max(0,(state.transferFinance?.spent||0)-(state.transferFinance?.received||0));
  const transferCommitment=netSpend*0.20;

  return annualFootballWages+transferCommitment;
}

function userSCRSnapshot(){
  const revenue=userFootballRevenue();
  const squadCost=userProjectedSquadCost();
  const ratio=revenue>0?squadCost/revenue:0;
  const greenLimit=revenue*0.85;
  const maxLimit=revenue*1.15;
  return {
    revenue,squadCost,ratio,
    status:ratio<=0.85?"Green":ratio<=1.15?"Amber":"Red",
    greenHeadroom:greenLimit-squadCost,
    maximumHeadroom:maxLimit-squadCost
  };
}

function aiFinanceSnapshot(club){
  const f=aiFinance(club);
  if(!f) return null;
  return {
    club,
    revenue:f.footballRevenue,
    transferBudget:f.transferBudget,
    wageBudget:f.wageBudget,
    weeklyWages:f.weeklyWages,
    transferSpent:f.transferSpent,
    transferReceived:f.transferReceived,
    netSpend:aiNetTransferSpend(club),
    scrRatio:aiSCRRatio(club),
    scrStatus:aiSCRStatus(club),
    scrHeadroom:aiSCRHeadroom(club),
    pressure:aiFinancialPressure(club),
    ownerType:f.ownerType
  };
}


/* --------------------------------------------------------------------------
   Transfer market engine
   -------------------------------------------------------------------------- */


// Calendar-based Premier League transfer-window model.
function transferWindowStatus(dateISO=(typeof currentGameDateISO==="function"?currentGameDateISO():"2025-08-08")){
  const d=parseISODate(dateISO);
  const y=d.getUTCFullYear();
  const md=dateISO.slice(5);

  // Premier League-style game windows. Exact future regulatory dates can be
  // updated later without altering the daily engine.
  const summerStart=`${y}-06-16`;
  const summerEnd=`${y}-09-01`;
  const winterStart=`${y}-01-01`;
  const winterEnd=`${y}-02-02`;

  if(dateISO>=summerStart && dateISO<=summerEnd){
    return {open:true,key:`summer-${y}`,name:"Summer transfer window",deadline:shortGameDate(summerEnd),next:`January ${y+1}`};
  }
  if(dateISO>=winterStart && dateISO<=winterEnd){
    return {open:true,key:`winter-${y}`,name:"January transfer window",deadline:shortGameDate(winterEnd),next:`Summer ${y}`};
  }

  if(md>"09-01"){
    return {open:false,key:`closed-autumn-${y}`,name:"Transfer window closed",deadline:null,next:`January ${y+1}`};
  }
  if(md<"06-16" && md>"02-02"){
    return {open:false,key:`closed-spring-${y}`,name:"Transfer window closed",deadline:null,next:`Summer ${y}`};
  }
  if(md<"01-01" || md>"09-01"){
    return {open:false,key:`closed-${y}`,name:"Transfer window closed",deadline:null,next:`January ${y+1}`};
  }
  return {open:false,key:`closed-${y}`,name:"Transfer window closed",deadline:null,next:`Summer ${y}`};
}

function isTransferWindowOpen(dateISO=(typeof currentGameDateISO==="function"?currentGameDateISO():undefined)){
  return transferWindowStatus(dateISO).open;
}

function transferWindowStatusHTML(){
  const w=transferWindowStatus();
  return `<div class="transfer-box" style="border:1px solid ${w.open?"#b7e3c4":"#e5c2c2"}"><b>${w.open?"TRANSFER WINDOW OPEN":"TRANSFER WINDOW CLOSED"}</b><br><span class="muted small">${w.open?`${w.name} • Deadline: ${w.deadline}`:`Next window: ${w.next}`}</span></div>`;
}

function blockClosedWindow(action="complete this transfer"){
  const w=transferWindowStatus();
  if(w.open) return false;
  addNews(`The transfer window is closed. ${action.charAt(0).toUpperCase()+action.slice(1)} is unavailable until ${w.next}.`);
  return true;
}

const TRANSFER_POSITION_GROUPS={
  GK:["GK"],
  RB:["RB","RWB"],
  CB:["CB"],
  LB:["LB","LWB"],
  DM:["CDM","DM"],
  CM:["CM"],
  AM:["CAM","AM"],
  RW:["RW","RM"],
  ST:["ST","CF"],
  LW:["LW","LM"]
};

function ensureTransferMarketState(){
  if(!state) return;
  if(!state.playerClubOverrides) state.playerClubOverrides={}; // legacy compatibility
  if(!state.playerWorldOverrides) state.playerWorldOverrides={};
  if(!state.transferLedger) state.transferLedger=[];
  if(!state.transferNegotiations) state.transferNegotiations={};
  if(!state.incomingTransferOffers) state.incomingTransferOffers=[];
  if(!state.aiTransferPlans) state.aiTransferPlans={};
  if(!state.transferReviewsRun) state.transferReviewsRun={};
  if(!state.managerSquadVacancies) state.managerSquadVacancies=[];

  // Re-apply this career's dynamic player-world changes.
  Object.entries(state.playerClubOverrides).forEach(([pid,club])=>{
    if(!state.playerWorldOverrides[pid]) state.playerWorldOverrides[pid]={club};
  });
  Object.entries(state.playerWorldOverrides).forEach(([pid,changes])=>{
    const p=DB.players.find(x=>String(x.id)===String(pid));
    if(p) Object.assign(p,changes);
  });
}

function playerPositionTokens(p){
  return String(p?.positions||"").toUpperCase().split(/[^A-Z]+/).filter(Boolean);
}

function playsPositionGroup(p,group){
  const wanted=TRANSFER_POSITION_GROUPS[group]||[group];
  const tokens=playerPositionTokens(p);
  return wanted.some(pos=>tokens.includes(pos));
}

function positionLabel(group){
  return ({GK:"goalkeeper",RB:"right-back",CB:"centre-back",LB:"left-back",DM:"defensive midfielder",CM:"central midfielder",AM:"attacking midfielder",RW:"right winger",ST:"striker",LW:"left winger"})[group] || group;
}

function stablePlayerTrait(p,salt="trait"){
  const str=String(p?.id??p?.name??"")+salt;
  let h=2166136261;
  for(let i=0;i<str.length;i++) h=Math.imul(h^str.charCodeAt(i),16777619);
  return ((h>>>0)%1000)/999;
}

function clubSquadPlayers(club){
  ensureTransferMarketState();
  return DB.players.filter(p=>p.club===club);
}


const MANAGER_FORMATIONS={
  "4-2-3-1":{slots:["GK","RB","CB","CB","LB","DM","DM","RW","AM","LW","ST"]},
  "4-3-3":{slots:["GK","RB","CB","CB","LB","DM","CM","CM","RW","LW","ST"]},
  "4-4-2":{slots:["GK","RB","CB","CB","LB","RM","CM","CM","LM","ST","ST"]},
  "4-2-2-2":{slots:["GK","RB","CB","CB","LB","DM","DM","AM","AM","ST","ST"]},
  "3-4-2-1":{slots:["GK","CB","CB","CB","RM","CM","CM","LM","AM","AM","ST"]},
  "3-4-3":{slots:["GK","CB","CB","CB","RM","CM","CM","LM","RW","LW","ST"]},
  "3-5-2":{slots:["GK","CB","CB","CB","RM","CM","DM","CM","LM","ST","ST"]}
};

// Real-world-inspired manager profiles for the 20 managers in the 2025/26 database.
// Formation, recruitment aggression, youth trust and depth demand currently affect AI.
// Possession, pressing, verticality and flexibility are exposed to the user now and are
// deliberately stored for future player-style recruitment and tactical systems.
const MANAGER_PROFILES={
  "Mikel Arteta":{
    preferredFormation:"4-3-3",alternatives:["4-2-3-1"],
    possession:92,pressing:88,verticality:52,flexibility:78,
    recruitmentAggression:84,youthTrust:68,depthDemand:92,
    summary:"Positional, possession-dominant football with aggressive counter-pressing and elite depth expectations."
  },
  "Unai Emery":{
    preferredFormation:"4-2-3-1",alternatives:["4-4-2","4-2-2-2"],
    possession:68,pressing:74,verticality:76,flexibility:90,
    recruitmentAggression:80,youthTrust:58,depthDemand:82,
    summary:"Highly adaptable, detail-heavy coach who favours a back four, double pivot, central combinations and quick progression."
  },
  "Andoni Iraola":{
    preferredFormation:"4-2-3-1",alternatives:["4-4-2"],
    possession:58,pressing:96,verticality:90,flexibility:70,
    recruitmentAggression:72,youthTrust:72,depthDemand:72,
    summary:"Relentless front-foot pressing, athleticism and rapid vertical attacks."
  },
  "Keith Andrews":{
    preferredFormation:"4-2-3-1",alternatives:["4-4-2"],
    possession:58,pressing:70,verticality:82,flexibility:65,
    recruitmentAggression:65,youthTrust:58,depthDemand:72,
    summary:"Compact and pragmatic, mixing controlled build-up with direct transitions and counter-attacking."
  },
  "Fabian Hürzeler":{
    preferredFormation:"4-2-3-1",alternatives:["3-4-2-1","3-4-3"],
    possession:84,pressing:78,verticality:58,flexibility:90,
    recruitmentAggression:70,youthTrust:86,depthDemand:76,
    summary:"Progressive possession coach with complex rotations, flexible structures and strong trust in younger players."
  },
  "Scott Parker":{
    preferredFormation:"4-2-3-1",alternatives:["4-3-3"],
    possession:76,pressing:62,verticality:48,flexibility:40,
    recruitmentAggression:58,youthTrust:60,depthDemand:70,
    summary:"Structured and organised, favouring controlled possession and a stable double-pivot framework."
  },
  "Enzo Maresca":{
    preferredFormation:"4-3-3",alternatives:["4-2-3-1"],
    possession:94,pressing:84,verticality:42,flexibility:68,
    recruitmentAggression:84,youthTrust:76,depthDemand:92,
    summary:"Highly positional possession football with patient build-up, technical demands and strong squad-depth expectations."
  },
  "Oliver Glasner":{
    preferredFormation:"3-4-2-1",alternatives:["4-2-3-1"],
    possession:50,pressing:84,verticality:82,flexibility:58,
    recruitmentAggression:72,youthTrust:62,depthDemand:78,
    summary:"Back-three specialist built around duels, counter-pressing and incisive transition attacks."
  },
  "David Moyes":{
    preferredFormation:"4-2-3-1",alternatives:["4-3-3"],
    possession:42,pressing:48,verticality:84,flexibility:55,
    recruitmentAggression:65,youthTrust:35,depthDemand:60,
    summary:"Experienced and pragmatic, favouring physical reliability, direct progression and proven senior options."
  },
  "Marco Silva":{
    preferredFormation:"4-2-3-1",alternatives:["4-4-2"],
    possession:62,pressing:62,verticality:76,flexibility:68,
    recruitmentAggression:70,youthTrust:58,depthDemand:74,
    summary:"Purposeful 4-2-3-1 football with progressive passing, wide rotations and balanced pressing."
  },
  "Daniel Farke":{
    preferredFormation:"4-2-3-1",alternatives:["4-3-3"],
    possession:88,pressing:76,verticality:52,flexibility:58,
    recruitmentAggression:68,youthTrust:72,depthDemand:72,
    summary:"Possession-first coach who wants his side to control matches, build patiently and attack from positional superiority."
  },
  "Arne Slot":{
    preferredFormation:"4-2-3-1",alternatives:["4-3-3"],
    possession:80,pressing:84,verticality:74,flexibility:76,
    recruitmentAggression:68,youthTrust:72,depthDemand:86,
    summary:"Controlled possession combined with aggressive pressing and purposeful vertical progression."
  },
  "Pep Guardiola":{
    preferredFormation:"4-3-3",alternatives:["4-2-3-1"],
    possession:99,pressing:94,verticality:48,flexibility:100,
    recruitmentAggression:94,youthTrust:70,depthDemand:96,
    summary:"Extreme positional control, technical quality and tactical fluidity, with exceptionally high squad standards."
  },
  "Ruben Amorim":{
    preferredFormation:"3-4-2-1",alternatives:["3-4-3"],
    possession:82,pressing:90,verticality:64,flexibility:35,
    recruitmentAggression:86,youthTrust:84,depthDemand:84,
    summary:"Committed back-three coach with aggressive pressing, wing-back dependency and strong faith in young players."
  },
  "Eddie Howe":{
    preferredFormation:"4-3-3",alternatives:["4-2-3-1","4-4-2"],
    possession:64,pressing:92,verticality:86,flexibility:80,
    recruitmentAggression:82,youthTrust:66,depthDemand:88,
    summary:"High-intensity pressing and quick transitions, with strong athletic and squad-depth demands."
  },
  "Nuno Espírito Santo":{
    preferredFormation:"4-2-3-1",alternatives:["3-4-3","3-5-2"],
    possession:38,pressing:52,verticality:92,flexibility:72,
    recruitmentAggression:68,youthTrust:45,depthDemand:68,
    summary:"Compact defensive organisation and rapid counter-attacking, with flexibility between back-four and back-three systems."
  },
  "Régis Le Bris":{
    preferredFormation:"4-3-3",alternatives:["4-2-3-1","4-4-2"],
    possession:62,pressing:84,verticality:82,flexibility:84,
    recruitmentAggression:64,youthTrust:90,depthDemand:70,
    summary:"Youth-oriented, energetic and adaptable, using aggressive pressing and fast attacks after regains."
  },
  "Thomas Frank":{
    preferredFormation:"4-2-3-1",alternatives:["3-5-2","4-3-3"],
    possession:64,pressing:86,verticality:82,flexibility:94,
    recruitmentAggression:78,youthTrust:74,depthDemand:80,
    summary:"Highly adaptable opponent-specific coach who blends pressing, direct attacks and multiple structures."
  },
  "Graham Potter":{
    preferredFormation:"3-4-2-1",alternatives:["4-2-3-1","3-5-2"],
    possession:84,pressing:76,verticality:56,flexibility:100,
    recruitmentAggression:68,youthTrust:82,depthDemand:78,
    summary:"Exceptionally flexible possession coach who values rotations, multi-functional players and youth."
  },
  "Vítor Pereira":{
    preferredFormation:"3-4-2-1",alternatives:["3-4-3"],
    possession:50,pressing:68,verticality:72,flexibility:38,
    recruitmentAggression:70,youthTrust:48,depthDemand:70,
    summary:"Tactically stable back-three coach with direct progression and a strong preference for structural consistency."
  }
};

const DEFAULT_MANAGER_PROFILE={
  preferredFormation:"4-2-3-1",alternatives:["4-3-3"],
  possession:65,pressing:65,verticality:65,flexibility:60,
  recruitmentAggression:65,youthTrust:60,depthDemand:70,
  summary:"Balanced managerial profile. A bespoke profile has not yet been added for this coach."
};

function managerNameForClub(club){
  return club===state.club ? state.staff?.manager?.name : (byClub(club)?.manager||"");
}

function managerProfileByName(name){
  return MANAGER_PROFILES[name] || DEFAULT_MANAGER_PROFILE;
}

function managerProfileForClub(club){
  return managerProfileByName(managerNameForClub(club));
}


function managerFormationForClub(club){
  const managerName=managerNameForClub(club);
  const profile=managerProfileByName(managerName);
  if(!state.managerTactics) state.managerTactics={};

  // Migration: old saves may contain a randomly assigned formation. The manager
  // profile now takes precedence and overwrites that legacy random assignment.
  state.managerTactics[club]={
    managerName,
    formation:profile.preferredFormation,
    alternatives:[...(profile.alternatives||[])]
  };
  return profile.preferredFormation;
}

function formationSlotAliases(slot){
  return ({
    GK:["GK"], RB:["RB","RWB"], LB:["LB","LWB"], CB:["CB"],
    DM:["CDM","DM","CM"], CM:["CM","CDM","CAM"], AM:["CAM","AM","CM"],
    RM:["RM","RW","LM","LW","RWB"], LM:["LM","LW","RM","RW","LWB"],
    RW:["RW","RM","LW","LM"], LW:["LW","LM","RW","RM"], ST:["ST","CF"]
  })[slot]||[slot];
}

function positionSuitability(p,slot){
  const tokens=playerPositionTokens(p);
  const primary=tokens[0]||"";
  const has=(...positions)=>positions.some(x=>tokens.includes(x));
  const primaryIs=(...positions)=>positions.includes(primary);

  if(slot==="GK") return has("GK")?100:0;

  // Full-backs are side-specific AND primary-position aware.
  // A natural/primary full-back should beat a higher-rated player who merely
  // has the role as a secondary position in the database.
  if(slot==="RB"){
    if(primaryIs("RB","RWB")) return 100;
    if(has("RB","RWB")) return 78;
    if(primaryIs("CB","RM")) return 48;
    if(has("CB","RM")) return 38;
    if(primaryIs("LB","LWB")) return 14;
    if(has("LB","LWB")) return 10;
    return 0;
  }
  if(slot==="LB"){
    if(primaryIs("LB","LWB")) return 100;
    if(has("LB","LWB")) return 78;
    if(primaryIs("CB","LM")) return 48;
    if(has("CB","LM")) return 38;
    if(primaryIs("RB","RWB")) return 14;
    if(has("RB","RWB")) return 10;
    return 0;
  }

  if(slot==="CB"){
    if(primaryIs("CB")) return 100;
    if(has("CB")) return 88;
    if(has("RB","LB","RWB","LWB")) return 58;
    if(has("CDM","DM")) return 50;
    return 0;
  }

  if(slot==="DM"){
    if(primaryIs("CDM","DM")) return 100;
    if(has("CDM","DM")) return 92;
    if(primaryIs("CM")) return 86;
    if(has("CM")) return 80;
    if(has("CB")) return 72;
    if(has("CAM","AM")) return 55;
    return 0;
  }

  if(slot==="CM"){
    if(primaryIs("CM")) return 100;
    if(has("CM")) return 92;
    if(has("CDM","DM","CAM","AM")) return 86;
    if(has("RM","LM")) return 66;
    return 0;
  }

  if(slot==="AM"){
    if(primaryIs("CAM","AM")) return 100;
    if(has("CAM","AM")) return 94;
    if(has("CM")) return 88;
    if(has("RW","LW","RM","LM")) return 80;
    if(has("ST","CF")) return 65;
    return 0;
  }

  // Wide roles remain deliberately flexible across flanks.
  if(slot==="RM"){
    if(primaryIs("RM")) return 100;
    if(primaryIs("RW")) return 96;
    if(has("RM","RW")) return 92;
    if(primaryIs("LM","LW")) return 84;
    if(has("LM","LW")) return 82;
    if(has("RWB")) return 70;
    if(has("CAM","AM")) return 72;
    return 0;
  }
  if(slot==="LM"){
    if(primaryIs("LM")) return 100;
    if(primaryIs("LW")) return 96;
    if(has("LM","LW")) return 92;
    if(primaryIs("RM","RW")) return 84;
    if(has("RM","RW")) return 82;
    if(has("LWB")) return 70;
    if(has("CAM","AM")) return 72;
    return 0;
  }
  if(slot==="RW"){
    if(primaryIs("RW")) return 100;
    if(primaryIs("RM")) return 96;
    if(has("RW","RM")) return 92;
    if(primaryIs("LW","LM")) return 84;
    if(has("LW","LM")) return 82;
    if(has("CAM","AM")) return 74;
    return 0;
  }
  if(slot==="LW"){
    if(primaryIs("LW")) return 100;
    if(primaryIs("LM")) return 96;
    if(has("LW","LM")) return 92;
    if(primaryIs("RW","RM")) return 84;
    if(has("RW","RM")) return 82;
    if(has("CAM","AM")) return 74;
    return 0;
  }

  if(slot==="ST"){
    if(primaryIs("ST","CF")) return 100;
    if(has("ST","CF")) return 94;
    if(has("CAM","AM")) return 70;
    if(has("RW","LW","RM","LM")) return 64;
    return 0;
  }

  return tokens.includes(slot)?100:0;
}

function playerFitsFormationSlot(p,slot){
  return positionSuitability(p,slot)>0;
}

function managerSelectXI(club){
  const formation=managerFormationForClub(club);
  const shape=MANAGER_FORMATIONS[formation]||MANAGER_FORMATIONS["4-2-3-1"];
  const available=clubSquadPlayers(club)
    .filter(p=>club!==state.club || !state.injuries?.[p.id]);

  const used=new Set();
  const xi=[];

  shape.slots.forEach((slot,slotIndex)=>{
    const candidates=available
      .filter(p=>!used.has(p.id))
      .map(p=>{
        const suitability=positionSuitability(p,slot);
        if(suitability<=0) return null;
        const stats=club===state.club ? state.playerStats?.[p.id] : null;
        const formBonus=stats?.lastRating ? (stats.lastRating-6.5)*0.8 : 0;
        const score=(p.overall||0)*0.72+suitability*0.28+formBonus;
        return {p,suitability,score};
      })
      .filter(Boolean)
      .sort((a,b)=>b.score-a.score || (b.p.overall||0)-(a.p.overall||0));

    const chosen=candidates[0]?.p||null;
    if(chosen) used.add(chosen.id);
    xi.push({
      slot,slotIndex,playerId:chosen?.id||null,player:chosen||null,
      overall:chosen?.overall||0,
      suitability:chosen?positionSuitability(chosen,slot):0
    });
  });

  return {formation,slots:shape.slots,xi};
}

function managerSelectMatchdaySquad(club){
  const selection=managerSelectXI(club);
  const used=new Set(selection.xi.filter(x=>x.playerId).map(x=>String(x.playerId)));
  const remaining=clubSquadPlayers(club)
    .filter(p=>club!==state.club || !state.injuries?.[p.id])
    .filter(p=>!used.has(String(p.id)))
    .sort((a,b)=>(b.overall||0)-(a.overall||0));

  // Seven-player bench for the current prototype. We store it now even before
  // substitutions are introduced so historical manager usage remains available.
  const bench=[];
  const wantedGroups=["GK","CB","RB","LB","DM","CM","AM","RW","LW","ST"];
  wantedGroups.forEach(slot=>{
    if(bench.length>=7) return;
    const best=remaining
      .filter(p=>!bench.some(b=>String(b.id)===String(p.id)))
      .map(p=>({p,score:(p.overall||0)*0.75+positionSuitability(p,slot)*0.25}))
      .filter(x=>positionSuitability(x.p,slot)>0)
      .sort((a,b)=>b.score-a.score)[0]?.p;
    if(best) bench.push(best);
  });
  remaining.forEach(p=>{if(bench.length<7 && !bench.some(b=>String(b.id)===String(p.id))) bench.push(p);});

  return {...selection,bench:bench.slice(0,7)};
}

function managerDepthChart(club){
  const selection=managerSelectXI(club);
  const chart={};
  selection.slots.forEach(slot=>{ if(!chart[slot]) chart[slot]={starters:[],backups:[]}; });
  selection.xi.forEach(x=>{ if(x.player) chart[x.slot].starters.push(x.player); });

  const startingIds=new Set(selection.xi.filter(x=>x.playerId).map(x=>String(x.playerId)));
  const remaining=clubSquadPlayers(club).filter(p=>!startingIds.has(String(p.id)));

  Object.keys(chart).forEach(slot=>{
    chart[slot].backups=remaining
      .map(p=>({p,suitability:positionSuitability(p,slot)}))
      .filter(x=>x.suitability>=40)
      .sort((a,b)=>{
        const scoreA=(a.p.overall||0)*0.72+a.suitability*0.28;
        const scoreB=(b.p.overall||0)*0.72+b.suitability*0.28;
        return scoreB-scoreA;
      })
      .slice(0,2)
      .map(x=>x.p);
  });
  return {formation:selection.formation,chart,xi:selection.xi};
}

function formationSlotToRecruitmentGroup(slot){
  return ({GK:"GK",RB:"RB",LB:"LB",CB:"CB",DM:"DM",CM:"CM",AM:"AM",RM:"RW",LM:"LW",RW:"RW",LW:"LW",ST:"ST"})[slot]||slot;
}

function managerSquadNeedsFromFormation(club){
  const depth=managerDepthChart(club);
  const rep=byClub(club)?.reputation||72;
  const profile=managerProfileForClub(club);

  const starterStandard=clamp(Math.round(70+(rep-70)*0.42),72,88);
  const competitionStandard=clamp(starterStandard-3,69,85);
  const backupStandard=clamp(starterStandard-8,64,81);
  const needs=[];

  [...new Set(depth.xi.map(x=>x.slot))].forEach(slot=>{
    const sameSlotXI=depth.xi.filter(x=>x.slot===slot);
    const starters=sameSlotXI.map(x=>x.player).filter(Boolean).sort((a,b)=>b.overall-a.overall);
    const backups=depth.chart[slot]?.backups||[];
    const requiredStarters=sameSlotXI.length;
    const filledStarters=starters.length;
    const weakestStarter=starters[starters.length-1]?.overall||0;
    const bestBackup=backups[0]?.overall||0;

    // One credible senior understudy is sufficient for a single GK slot.
    // Other positions scale depth expectations with how many slots the formation uses
    // and with the manager's profile.
    const seniorBackupsRequired = slot==="GK"
      ? 1
      : Math.max(1,Math.min(2,requiredStarters + (profile.depthDemand>=88?1:0)));

    const credibleSeniorBackups=backups.filter(p=>(p.overall||0)>=backupStandard-6).length;

    const prospectCandidates=clubSquadPlayers(club).filter(p=>{
      if(!playerFitsFormationSlot(p,slot)) return false;
      if(p.age>22) return false;
      const potential=p.potential||p.overall||0;
      return potential>=Math.max(competitionStandard,starterStandard-2);
    });

    let role="none",score=0,reason="";

    if(filledStarters<requiredStarters){
      role="starter"; score=92;
      reason=`The ${depth.formation} requires ${requiredStarters} ${slot} role${requiredStarters>1?"s":""}, but only ${filledStarters} is currently filled.`;
    }else if(weakestStarter<starterStandard-3){
      role="starter"; score=65+(starterStandard-weakestStarter)*5;
      reason=`The current ${slot} starter is below the level expected for this club.`;
    }else if(bestBackup<competitionStandard-5){
      role="competition"; score=46+(competitionStandard-bestBackup)*4;
      reason=`The manager wants stronger competition behind the ${slot} starter${requiredStarters>1?"s":""}.`;
    }else if(credibleSeniorBackups<seniorBackupsRequired){
      role="backup";
      score=26+(seniorBackupsRequired-credibleSeniorBackups)*10+(profile.depthDemand-70)*0.25;
      reason=`The ${slot} depth is below ${managerNameForClub(club)}'s preferred senior cover level.`;
    }else if(
      profile.youthTrust>=68 &&
      prospectCandidates.length===0 &&
      (slot==="GK" || profile.depthDemand>=78)
    ){
      role="prospect";
      score=20+(profile.youthTrust-60)*0.35+(profile.depthDemand-70)*0.15;
      reason=`Senior ${slot} cover is adequate, but ${managerNameForClub(club)} would like a young development option for the future.`;
    }

    needs.push({
      position:formationSlotToRecruitmentGroup(slot),
      tacticalSlot:slot,role,score:clamp(Math.round(score),0,100),reason,
      formation:depth.formation,
      starter:starters[0]?.overall||0,second:bestBackup,depth:starters.length+backups.length,
      standards:{starter:starterStandard,competition:competitionStandard,backup:backupStandard},
      managerProfile:profile
    });
  });

  const merged={};
  needs.forEach(n=>{ if(!merged[n.position] || n.score>merged[n.position].score) merged[n.position]=n; });
  return Object.values(merged).sort((a,b)=>b.score-a.score);
}

function evaluateSquadNeeds(club){
  return managerSquadNeedsFromFormation(club);
}

function playerInterestScore(p,buyingClub=state.club){
  const buyer=byClub(buyingClub);
  const seller=byClub(p.club);
  const buyerRep=buyer?.reputation||70;
  const sellerRep=seller?.reputation||70;
  const ambition=stablePlayerTrait(p,"ambition");
  const age=p.age||25;

  let score=52+(buyerRep-sellerRep)*2.4;
  // Ambitious players care more about an upward move; less ambitious players are
  // somewhat more open to sideways moves.
  score+=(ambition-0.5)*(buyerRep>=sellerRep?14:-18);
  if(age<=23 && buyerRep>=80) score+=5;
  if(buyingClub===state.club && typeof facilityRating==="function"){
    score+=(facilityRating("recruitment")-70)*0.08;
  }
  if(p.club===buyingClub) score=100;
  return clamp(Math.round(score),0,100);
}

function interestLabel(score){
  if(score>=82) return "Very high";
  if(score>=68) return "High";
  if(score>=50) return "Moderate";
  if(score>=33) return "Low";
  return "Very low";
}

function wageInterestMultiplier(score){
  if(score>=82) return 1.00;
  if(score>=68) return 1.04;
  if(score>=50) return 1.10;
  if(score>=33) return 1.22;
  return 1.40;
}

function managerInterestScore(p){
  if(!state?.club) return 50;
  const needs=evaluateSquadNeeds(state.club);
  const matching=needs.filter(n=>playsPositionGroup(p,n.position));
  const need=matching.length?matching[0].score:20;
  const team=strength(state.club);
  let score=28+need*0.48+(p.overall-team)*5.5;
  if(p.age>=32) score-=8;
  if(p.age<=24 && p.potential>=p.overall+4) score+=5;
  return clamp(Math.round(score),0,100);
}

function dofInterestScore(p){
  const matching=evaluateSquadNeeds(state.club).filter(n=>playsPositionGroup(p,n.position));
  const need=matching.length?matching[0].score:20;
  const value=Math.max(1,p.value||1);
  const upside=Math.max(0,(p.potential||p.overall)-p.overall);
  let score=30+need*0.34+(p.overall-strength(state.club))*3.0+upside*3.2;
  if(p.age<=23) score+=9;
  if(p.age>=29) score-=Math.min(22,(p.age-28)*5);
  // Expensive players need to be correspondingly excellent.
  const valueMillions=value/1_000_000;
  if(valueMillions>70 && p.overall<84) score-=10;
  if(valueMillions<35 && p.overall>=80) score+=8;
  return clamp(Math.round(score),0,100);
}

function staffInterestLabel(score){
  if(score>=80) return "Very interested";
  if(score>=63) return "Interested";
  if(score>=45) return "Open to deal";
  if(score>=28) return "Low interest";
  return "Not interested";
}

function estimatedAskingPrice(p,buyingClub=state.club){
  const value=Math.max(250000,p.value||0);
  const sellerRep=byClub(p.club)?.reputation||70;
  const buyerRep=byClub(buyingClub)?.reputation||70;
  const contractYear=state.playerContracts?.[p.id]?.endYear ?? p.contract ?? 2028;
  const years=Math.max(0,contractYear-currentSeasonStartYear());
  let mult=1.08;
  if(years>=4) mult+=0.14;
  else if(years<=1) mult-=0.17;
  if(p.age<=23 && (p.potential||p.overall)>=p.overall+4) mult+=0.14;
  if(p.overall>=84) mult+=0.10;
  if(buyerRep>sellerRep+8) mult+=0.05;
  // Deterministic club-specific variance avoids every deal being value × same number.
  mult+=((stablePlayerTrait(p,"ask")-0.5)*0.12);
  if(p.club!==state.club && state.aiClubFinances?.[p.club]){
    mult*=aiSaleWillingnessModifier(p.club);
  }
  return Math.max(value,Math.round((value*mult)/250000)*250000);
}

function expectedTransferWage(p,buyingClub=state.club){
  const current=Math.max(1000,state.playerContracts?.[p.id]?.wage ?? p.wage ?? 1000);
  const interest=playerInterestScore(p,buyingClub);
  let demand=current*wageInterestMultiplier(interest);
  if((p.overall||0)>=84) demand*=1.08;
  if((p.overall||0)>=88) demand*=1.08;
  const step=demand>=100000?5000:demand>=50000?2500:1000;
  return Math.round(demand/step)*step;
}

function findTransferTargets(club,position,limit=6){
  const rep=byClub(club)?.reputation||70;
  const budget=club===state.club
    ? (state.budget||0)
    : (aiFinance(club)?.transferBudget||Math.max(15_000_000,(rep-65)*4_000_000));
  const currentStrength=club===state.club?strength(club):(()=>{
    const arr=clubSquadPlayers(club).map(p=>p.overall).sort((a,b)=>b-a).slice(0,16);
    return arr.length?arr.reduce((a,b)=>a+b,0)/arr.length:70;
  })();

  return DB.players
    .filter(p=>p.club!==club && playsPositionGroup(p,position))
    .map(player=>{
      const interest=playerInterestScore(player,club);
      const asking=estimatedAskingPrice(player,club);
      const abilityFit=(player.overall-currentStrength)*8;
      const upside=Math.max(0,(player.potential||player.overall)-player.overall)*2;
      const affordability=asking<=budget*1.15?12:asking<=budget*1.6?0:-18;
      const score=50+abilityFit+upside+interest*0.18+affordability-(player.age>=31?10:0);
      return {player,score,asking,interest};
    })
    .filter(x=>x.player.overall>=Math.max(68,currentStrength-5))
    .sort((a,b)=>b.score-a.score)
    .slice(0,limit);
}

function currentGameMonthYear(){
  return parseISODate(currentGameDateISO()).toLocaleDateString("en-GB",{month:"short",year:"numeric",timeZone:"UTC"});
}

function transferPlayerToClub(p,newClub,fee,fromClub=p.club,details={}){
  ensureTransferMarketState();
  const oldClub=fromClub;
  const joined=currentGameMonthYear();

  state.playerWorldOverrides[p.id]={
    ...(state.playerWorldOverrides[p.id]||{}),
    club:newClub,
    joined
  };
  state.playerClubOverrides[p.id]=newClub;
  p.club=newClub;
  p.joined=joined;

  state.transferLedger.push({
    id:"tx"+Date.now()+Math.floor(Math.random()*1000),week:state.week,date:currentGameDateISO(),playerId:p.id,playerName:p.name,
    fromClub:oldClub,toClub:newClub,fee,kind:details.kind||"permanent",joined,season:currentSeasonLabel()
  });
  state.transferLedger=state.transferLedger.slice(-120);
}

function transferDossier(p){
  const interest=playerInterestScore(p,state.club);
  const manager=managerInterestScore(p);
  const dof=dofInterestScore(p);
  const asking=estimatedAskingPrice(p,state.club);
  const wage=expectedTransferWage(p,state.club);
  return {interest,manager,dof,asking,wage};
}

function ensureTransferPlayerModal(){
  if(document.getElementById("transferPlayerModal")) return;
  const style=document.createElement("style");
  style.textContent=`
    #transferPlayerModal{position:fixed;inset:0;background:rgba(8,12,20,.72);z-index:9999;display:flex;align-items:center;justify-content:center;padding:18px}
    #transferPlayerModal.hide{display:none}
    #transferPlayerModal .transfer-sheet{width:min(760px,100%);max-height:92vh;overflow:auto;background:#fff;color:#18202b;border-radius:16px;padding:22px;box-shadow:0 24px 70px rgba(0,0,0,.35)}
    #transferPlayerModal .transfer-head{display:flex;justify-content:space-between;gap:15px;align-items:flex-start;margin-bottom:16px}
    #transferPlayerModal .transfer-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:14px 0}
    #transferPlayerModal .transfer-metric{border:1px solid #e4e8ee;border-radius:10px;padding:12px}
    #transferPlayerModal .transfer-metric span{display:block;font-size:12px;color:#667085;margin-bottom:4px}
    #transferPlayerModal .transfer-metric b{font-size:16px}
    #transferPlayerModal .transfer-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:14px}
    #transferPlayerModal .transfer-box{background:#f6f8fb;border-radius:10px;padding:13px;margin-top:14px}
    #transferPlayerModal input,#transferPlayerModal select{padding:9px;border:1px solid #cfd5df;border-radius:8px;max-width:180px}
    #transferPlayerModal button{cursor:pointer}
    @media(max-width:600px){#transferPlayerModal .transfer-grid{grid-template-columns:1fr}.transfer-sheet{padding:16px!important}}
  `;
  document.head.appendChild(style);

  const modal=document.createElement("div");
  modal.id="transferPlayerModal";
  modal.className="hide";
  modal.innerHTML=`<div class="transfer-sheet">
    <div class="transfer-head"><div><h2 id="transferFileName" style="margin:0"></h2><div id="transferFileSub" class="muted"></div></div><button class="btn secondary" id="closeTransferFile">Close</button></div>
    <div id="transferFileBody"></div>
  </div>`;
  document.body.appendChild(modal);
  modal.addEventListener("click",e=>{if(e.target===modal) closeTransferPlayerFile();});
  modal.querySelector("#closeTransferFile").addEventListener("click",closeTransferPlayerFile);
}

function openTransferPlayerFile(id,context={}){
  ensureContractState();
  const p=DB.players.find(x=>String(x.id)===String(id));
  if(!p) return;
  if(p.club===state.club && typeof openPlayerProfile==="function"){
    openPlayerProfile(p.id);
    return;
  }
  ensureTransferPlayerModal();
  const d=transferDossier(p);
  const joined=p.joined||"Unknown";
  const contract=state.playerContracts?.[p.id]?.endYear ?? p.contract ?? "Unknown";
  const active=state.transferNegotiations?.[p.id];

  q("transferFileName").textContent=p.name;
  q("transferFileSub").textContent=`${p.club} • ${p.positions} • ${p.age} • ${p.nationality}`;
  q("transferFileBody").innerHTML=`
    <div class="transfer-grid">
      <div class="transfer-metric"><span>Joined current club</span><b>${joined}</b></div>
      <div class="transfer-metric"><span>Transfer market value</span><b>${money(p.value)}</b></div>
      <div class="transfer-metric"><span>Current wage</span><b>${money(p.wage||0)}/wk</b></div>
      <div class="transfer-metric"><span>Contract</span><b>${contract}</b></div>
      <div class="transfer-metric"><span>Interest in joining ${state.club}</span><b>${interestLabel(d.interest)}</b></div>
      <div class="transfer-metric"><span>Manager interest</span><b>${staffInterestLabel(d.manager)}</b></div>
      <div class="transfer-metric"><span>Director of Football interest</span><b>${staffInterestLabel(d.dof)}</b></div>
      <div class="transfer-metric"><span>Recruitment estimate</span><b>${money(Math.round(d.asking*.92/250000)*250000)}–${money(Math.round(d.asking*1.08/250000)*250000)}</b></div>
    </div>
    <div class="transfer-box">
      <b>Recruitment view</b><br>
      <span class="muted small">Expected wage demand: around ${money(d.wage)}/wk. Lower player interest increases the wage premium needed to complete a deal.</span>
    </div>
    ${transferWindowStatusHTML()}
    <div id="transferNegotiationArea"></div>
    <div class="transfer-actions">
      <button class="btn primary" id="authoriseTransferApproach" ${isTransferWindowOpen()?"":"disabled"}>${isTransferWindowOpen()?(active?"Continue negotiation":"Authorise approach"):"Window closed"}</button>
    </div>`;
  q("authoriseTransferApproach").addEventListener("click",()=>beginTransferApproach(p.id,context));
  q("transferPlayerModal").classList.remove("hide");
  if(active) renderTransferNegotiation(p.id);
}

function closeTransferPlayerFile(){
  q("transferPlayerModal")?.classList.add("hide");
}


function transferSellerReservationPrice(n){
  // The DoF should help, but not magically turn a £130m player into a £95m sale.
  // Translate the existing DoF modifier into a capped 0–8% negotiating advantage.
  const rawModifier=dofNegotiationModifier();
  const dofAdvantage=clamp((1-rawModifier)*0.40,-0.04,0.08);
  return Math.round((n.askingPrice*(0.97-dofAdvantage))/250000)*250000;
}

function initialSellerCounter(n){
  const reservation=transferSellerReservationPrice(n);
  const opening=Math.round((n.askingPrice*(1.00+stablePlayerTrait({id:n.playerId},"seller-counter")*0.035))/250000)*250000;
  return Math.max(reservation,opening);
}

function beginTransferApproach(id,context={}){
  ensureContractState();
  if(blockClosedWindow("authorise an approach")) return;
  const p=DB.players.find(x=>String(x.id)===String(id));
  if(!p || p.club===state.club) return;
  if(!state.transferNegotiations[p.id]){
    const asking=estimatedAskingPrice(p,state.club);
    const suggested=Math.round((asking*.82)/250000)*250000;
    const negotiation={
      playerId:p.id,sellingClub:p.club,buyingClub:state.club,askingPrice:asking,
      latestOffer:suggested,round:0,status:"negotiating",managerRequestId:context.managerRequestId||null,
      previousUserOffer:0,lastCounter:null,stagnantRounds:0
    };
    negotiation.reservationPrice=transferSellerReservationPrice(negotiation);
    negotiation.lastCounter=initialSellerCounter(negotiation);
    state.transferNegotiations[p.id]=negotiation;
  }
  renderTransferNegotiation(p.id);
}

function renderTransferNegotiation(id){
  const p=DB.players.find(x=>String(x.id)===String(id));
  const n=state.transferNegotiations?.[id];
  const area=q("transferNegotiationArea");
  if(!p||!n||!area) return;

  if(n.status==="clubAccepted" || n.status==="terms"){
    const demand=expectedTransferWage(p,state.club);
    area.innerHTML=`<div class="transfer-box"><b>${n.sellingClub} accepted ${money(n.agreedFee)}.</b><br><span class="muted small">You can now agree terms with ${p.name}.</span>
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px;align-items:center">
        <label>Weekly wage <input id="newSigningWage" type="number" step="1000" value="${demand}"></label>
        <label>Contract <select id="newSigningYears"><option>3</option><option selected>4</option><option>5</option></select> years</label>
        <button class="btn primary" id="submitSigningTerms">Offer contract</button>
      </div>
      <div class="muted small" style="margin-top:8px">Agent expectation: around ${money(demand)}/wk • Player interest: ${interestLabel(playerInterestScore(p,state.club))}.</div>
    </div>`;
    q("submitSigningTerms").addEventListener("click",()=>submitNewSigningTerms(p.id));
    return;
  }

  if(n.status==="rejected"){
    area.innerHTML=`<div class="transfer-box"><b>Approach ended.</b><br><span class="muted small">${n.sellingClub} rejected the negotiation.</span></div>`;
    return;
  }

  area.innerHTML=`<div class="transfer-box">
    <b>Club negotiation — ${n.sellingClub}</b><br>
    <span class="muted small">Recruitment estimates the player may cost around ${money(Math.round(n.askingPrice*.92/250000)*250000)}–${money(Math.round(n.askingPrice*1.08/250000)*250000)}.</span>
    ${n.message?`<div style="margin-top:8px">${n.message}</div>`:""}
    ${n.lastCounter?`<div class="muted small" style="margin-top:6px">Current counter: ${money(n.lastCounter)} • Match this amount to accept.</div>`:""}
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px;align-items:center">
      <label>Transfer fee <input id="transferFeeOffer" type="number" step="250000" value="${n.latestOffer}"></label>
      <button class="btn primary" id="submitTransferBid">Submit bid</button>
      <button class="btn secondary" id="walkAwayTransfer">Walk away</button>
    </div>
  </div>`;
  q("submitTransferBid").addEventListener("click",()=>submitTransferBid(p.id,Number(q("transferFeeOffer").value||0)));
  q("walkAwayTransfer").addEventListener("click",()=>{n.status="rejected";n.message="You ended negotiations.";saveGame(false);renderTransferNegotiation(p.id);});
}

function submitTransferBid(id,fee){
  if(blockClosedWindow("submit a transfer bid")) return;

  const p=DB.players.find(x=>String(x.id)===String(id));
  const n=state.transferNegotiations?.[id];
  if(!p||!n||fee<=0) return;

  const offer=Math.round(fee/250000)*250000;

  // Migrate older/in-progress negotiations safely.
  if(n.reservationPrice==null) n.reservationPrice=transferSellerReservationPrice(n);
  if(n.lastCounter==null) n.lastCounter=initialSellerCounter(n);
  if(n.previousUserOffer==null) n.previousUserOffer=0;
  if(n.stagnantRounds==null) n.stagnantRounds=0;

  const reservation=n.reservationPrice;
  const sellerCounter=n.lastCounter;
  const previousOffer=n.previousUserOffer;

  n.round=(n.round||0)+1;

  // ABSOLUTE RULE:
  // If the buyer meets or exceeds the seller's current counter, the deal is accepted.
  if(offer>=sellerCounter){
    n.status="clubAccepted";
    n.agreedFee=offer;
    n.latestOffer=offer;
    n.previousUserOffer=offer;
    n.message=`${n.sellingClub} accepted your offer of ${money(offer)}.`;
    addNews(`${n.sellingClub} have accepted ${state.club}'s ${money(offer)} offer for ${p.name}.`);
    saveGame(false);
    renderTransferNegotiation(p.id);
    return;
  }

  // Also accept if the bid reaches the seller's internal minimum.
  if(offer>=reservation){
    n.status="clubAccepted";
    n.agreedFee=offer;
    n.latestOffer=offer;
    n.previousUserOffer=offer;
    n.message=`${n.sellingClub} accepted your offer of ${money(offer)}.`;
    addNews(`${n.sellingClub} have accepted ${state.club}'s ${money(offer)} offer for ${p.name}.`);
    saveGame(false);
    renderTransferNegotiation(p.id);
    return;
  }

  const improvement=offer-previousOffer;

  // Same/lower bid: seller does not move at all.
  if(previousOffer>0 && improvement<=0){
    n.stagnantRounds+=1;
    n.previousUserOffer=offer;
    n.latestOffer=sellerCounter;

    if(n.stagnantRounds>=2 || n.round>=6){
      n.status="rejected";
      n.message=`${n.sellingClub} ended negotiations after you failed to improve your offer.`;
    }else{
      n.message=`${n.sellingClub} rejected the bid. Their counter remains ${money(sellerCounter)}.`;
    }

    saveGame(false);
    renderTransferNegotiation(p.id);
    return;
  }

  n.stagnantRounds=0;

  // Very low bids do not earn any seller concession.
  if(offer<reservation*0.82){
    n.previousUserOffer=offer;
    n.latestOffer=sellerCounter;
    n.message=`${n.sellingClub} rejected the bid as well below their valuation. Their counter remains ${money(sellerCounter)}.`;

    if(n.round>=3){
      n.status="rejected";
      n.message=`${n.sellingClub} have ended negotiations after repeated low offers.`;
    }

    saveGame(false);
    renderTransferNegotiation(p.id);
    return;
  }

  // Improved bids can earn a SMALL seller concession.
  // The seller never counters below:
  // 1) their reservation price
  // 2) the buyer's submitted offer + £250k
  // This prevents impossible "we counter below your offer but still reject it" states.
  const concession=Math.max(
    0,
    Math.min(
      sellerCounter-reservation,
      Math.round((Math.max(250000,improvement)*0.35)/250000)*250000
    )
  );

  let newCounter=Math.max(
    reservation,
    sellerCounter-concession,
    offer+250000
  );

  // Round safely
  newCounter=Math.round(newCounter/250000)*250000;

  // Defensive guarantee: if rounding somehow takes the counter to/below the offer,
  // accept the user's offer rather than creating a contradictory state.
  if(newCounter<=offer){
    n.status="clubAccepted";
    n.agreedFee=offer;
    n.latestOffer=offer;
    n.previousUserOffer=offer;
    n.lastCounter=offer;
    n.message=`${n.sellingClub} accepted your offer of ${money(offer)}.`;
    addNews(`${n.sellingClub} have accepted ${state.club}'s ${money(offer)} offer for ${p.name}.`);
  }else{
    n.previousUserOffer=offer;
    n.lastCounter=newCounter;
    n.latestOffer=newCounter;
    n.message=`${n.sellingClub} rejected the bid and countered at ${money(newCounter)}.`;

    if(n.round>=6 && offer<reservation*0.94){
      n.status="rejected";
      n.message=`${n.sellingClub} have ended negotiations because your offers remained below their valuation.`;
    }
  }

  saveGame(false);
  renderTransferNegotiation(p.id);
}

function submitNewSigningTerms(id){
  if(blockClosedWindow("complete a permanent transfer")) return;
  const p=DB.players.find(x=>String(x.id)===String(id));
  const n=state.transferNegotiations?.[id];
  if(!p||!n||n.status!=="clubAccepted") return;
  const wage=Math.max(1000,Number(q("newSigningWage")?.value||0));
  const years=Math.max(1,Number(q("newSigningYears")?.value||4));
  const demand=expectedTransferWage(p,state.club);
  const interest=playerInterestScore(p,state.club);

  let chance=0.36+(wage/demand-1)*1.7+(interest-50)/180;
  if(years>=4 && p.age<=29) chance+=0.06;
  chance=clamp(chance,0.04,0.96);

  if(Math.random()>chance){
    n.status="clubAccepted";
    addNews(`${p.name}'s representatives rejected ${state.club}'s contract offer.`);
    const area=q("transferNegotiationArea");
    if(area){
      const old=area.querySelector(".transfer-box");
      if(old) old.insertAdjacentHTML("afterbegin",`<div class="bad" style="margin-bottom:8px"><b>Contract offer rejected.</b></div>`);
    }
    return;
  }

  if((state.budget||0)<n.agreedFee){
    addNews(`The ${p.name} deal could not be completed because the transfer budget is insufficient.`);
    return;
  }

  const oldClub=p.club;
  const oldAIWage=p.wage||0;
  state.budget-=n.agreedFee;
  if(state.transferFinance) state.transferFinance.spent=(state.transferFinance.spent||0)+n.agreedFee;
  if(state.monthlyFinance) state.monthlyFinance.transferSpent=(state.monthlyFinance.transferSpent||0)+n.agreedFee;
  if(oldClub!==state.club && aiFinance(oldClub)){
    applyAITransferSale(oldClub,n.agreedFee,oldAIWage);
  }
  transferPlayerToClub(p,state.club,n.agreedFee,oldClub);

  // If this signing came from a manager request, satisfy that specific role and
  // stop the manager immediately asking for the same thing again.
  const req=n.managerRequestId ? state.managerRequests?.find(r=>r.id===n.managerRequestId) : null;
  if(req?.type==="sign"){
    const signedGroup=primaryRecruitmentGroup(p);

    (state.managerSquadVacancies||[])
      .filter(v=>!v.filled && v.position===req.position)
      .forEach(v=>{
        const need=evaluateSquadNeeds(state.club).find(x=>x.position===req.position);
        const standards=need?.standards||{};
        const ovr=p.overall||0;
        const threshold =
          v.role==="starter" ? (standards.starter||75)-3 :
          v.role==="competition" ? (standards.competition||72)-4 :
          (standards.backup||68)-5;

        if(ovr>=threshold) v.filled=true;
      });

    if(!state.managerRoleFulfilledUntil) state.managerRoleFulfilledUntil={};
    state.managerRoleFulfilledUntil[`${req.position}-${req.squadRole||"starter"}`]=currentCareerDay()+84;
  }

  state.playerContracts[p.id]={wage,endYear:currentSeasonStartYear()+years};
  p.wage=wage;
  state.playerMorale[p.id]="Happy";
  if(!state.playerStats[p.id]) state.playerStats[p.id]={appearances:0,goals:0};
  state.playerListStatus[p.id]="None";
  n.status="completed";
  if(p.overall>=82 || n.agreedFee>=40_000_000) recordMarqueeSigning(p);
  state.transferSentiment.owners.push({label:`Transfer spending on ${p.name}`,value:n.agreedFee>(p.value||0)*1.25?-3:1});
  addNews(`${state.club} have signed ${p.name} from ${oldClub} for ${money(n.agreedFee)}. ${p.name} has agreed a ${years}-year contract worth ${money(wage)}/week.`);
  saveGame(false);
  closeTransferPlayerFile();
  renderAll();
}


function playerSaleDecisionStatsHTML(p){
  const s=state.playerStats?.[p.id]||{};
  const avg=typeof playerAverageRating==="function"?playerAverageRating(p.id):null;
  return `<div class="sale-decision-stats">
    <div><span>Apps</span><b>${s.appearances||0}</b></div>
    <div><span>Goals</span><b>${s.goals||0}</b></div>
    <div><span>AVG rating</span><b>${avg!=null?avg.toFixed(2):"—"}</b></div>
  </div>`;
}

function incomingOfferFairValue(p){
  return Math.round(estimatedAskingPrice(p,state.club)/250000)*250000;
}

function generateIncomingOffer(){
  ensureContractState();
  if(!isTransferWindowOpen()) return;
  const candidates=squad(state.club).filter(p=>{
    const listed=state.playerListStatus?.[p.id]==="Transfer";
    const strong=p.overall>=74;
    return listed || strong;
  });
  if(!candidates.length) return;

  // Listed players are much more likely to attract attention.
  const weighted=[];
  candidates.forEach(p=>{
    let w=1;
    if(state.playerListStatus?.[p.id]==="Transfer") w+=5;
    if(p.overall>=82) w+=2;
    for(let i=0;i<w;i++) weighted.push(p);
  });
  const p=weighted[Math.floor(Math.random()*weighted.length)];
  if(state.incomingTransferOffers.some(o=>o.playerId===p.id && o.status==="pending")) return;

  const interestedClubs=DB.clubs.filter(c=>c.name!==state.club).filter(c=>{
    const needs=evaluateSquadNeeds(c.name).slice(0,3);
    return needs.some(n=>playsPositionGroup(p,n.position));
  });
  if(!interestedClubs.length) return;
  const fair=incomingOfferFairValue(p);
  const affordableBuyers=interestedClubs.filter(c=>{
    const expectedWage=expectedTransferWage(p,c.name);
    return aiCanAffordTransfer(c.name,fair*.85,expectedWage).ok;
  });
  if(!affordableBuyers.length) return;

  const buyer=affordableBuyers[Math.floor(Math.random()*affordableBuyers.length)];
  const listed=state.playerListStatus?.[p.id]==="Transfer";
  const fee=Math.round((fair*(listed?0.82+Math.random()*.16:0.88+Math.random()*.22))/250000)*250000;
  const wage=expectedTransferWage(p,buyer.name);
  if(!aiCanAffordTransfer(buyer.name,fee,wage).ok) return;
  const offer={id:"io"+Date.now()+Math.floor(Math.random()*1000),playerId:p.id,buyingClub:buyer.name,fee,status:"pending",round:1,expectedWage:wage};
  state.incomingTransferOffers.push(offer);
  state.news.unshift({week:state.week,date:currentGameDateISO(),text:`${buyer.name} have submitted a ${money(fee)} offer for ${p.name}.`,incomingOfferId:offer.id});
}

function incomingOfferViews(offer){
  const p=DB.players.find(x=>String(x.id)===String(offer.playerId));
  const fair=incomingOfferFairValue(p);
  const ratio=offer.fee/fair;
  const mgr=managerInterestScore(p);
  let manager= mgr>=70?"Keep — important to first-team plans":mgr>=50?"Open to sale at the right price":"Would sanction a sale";
  let dof=ratio>=1.08?"Recommend accepting — strong value":ratio>=0.94?"Fair offer — negotiate if possible":"Recommend rejecting — below valuation";
  return {p,fair,manager,dof};
}

function openIncomingTransferOffer(id){
  const offer=state.incomingTransferOffers?.find(o=>o.id===id);
  if(!offer||offer.status!=="pending") return;
  const v=incomingOfferViews(offer);
  ensureTransferPlayerModal();
  q("transferFileName").textContent=`Offer for ${v.p.name}`;
  q("transferFileSub").textContent=`${offer.buyingClub} → ${state.club}`;
  q("transferFileBody").innerHTML=`
    <div class="transfer-grid">
      <div class="transfer-metric"><span>Offer</span><b>${money(offer.fee)}</b></div>
      <div class="transfer-metric"><span>Market value</span><b>${money(v.p.value)}</b></div>
      <div class="transfer-metric"><span>Internal fair-value estimate</span><b>${money(v.fair)}</b></div>
      <div class="transfer-metric"><span>Player morale</span><b>${state.playerMorale?.[v.p.id]||"Content"}</b></div>
      <div class="transfer-metric"><span>Manager view</span><b>${v.manager}</b></div>
      <div class="transfer-metric"><span>DOF view</span><b>${v.dof}</b></div>
    </div>
    ${playerSaleDecisionStatsHTML(v.p)}
    <div class="transfer-actions">
      <button class="btn primary" id="acceptIncomingOffer">Accept</button>
      <button class="btn secondary" id="rejectIncomingOffer">Reject</button>
      <label>Counter <input id="incomingCounterFee" type="number" step="250000" value="${Math.round(v.fair/250000)*250000}"></label>
      <button class="btn secondary" id="counterIncomingOffer">Negotiate</button>
    </div>`;
  q("acceptIncomingOffer").addEventListener("click",()=>resolveIncomingTransferOffer(id,"accept"));
  q("rejectIncomingOffer").addEventListener("click",()=>resolveIncomingTransferOffer(id,"reject"));
  q("counterIncomingOffer").addEventListener("click",()=>resolveIncomingTransferOffer(id,"counter",Number(q("incomingCounterFee").value||0)));
  q("transferPlayerModal").classList.remove("hide");
}

function resolveIncomingTransferOffer(id,action,counter=0){
  if(blockClosedWindow("respond to a permanent-transfer offer")) return;
  const offer=state.incomingTransferOffers?.find(o=>o.id===id);
  if(!offer||offer.status!=="pending") return;
  const p=DB.players.find(x=>String(x.id)===String(offer.playerId));
  if(!p) return;
  const fair=incomingOfferFairValue(p);

  if(action==="reject"){
    offer.status="rejected";
    addNews(`${state.club} rejected ${offer.buyingClub}'s ${money(offer.fee)} offer for ${p.name}.`);
    closeTransferPlayerFile();
  }else if(action==="counter"){
    counter=Math.round(counter/250000)*250000;
    const ceiling=fair*(0.98+stablePlayerTrait(p,offer.buyingClub)*0.20);
    if(counter<=ceiling){
      offer.fee=counter;
      action="accept";
    }else{
      offer.round++;
      if(offer.round>=3 || counter>ceiling*1.16){
        offer.status="rejected";
        addNews(`${offer.buyingClub} withdrew from talks for ${p.name} after rejecting ${state.club}'s ${money(counter)} asking price.`);
        closeTransferPlayerFile();
      }else{
        const revised=Math.round((ceiling*.97)/250000)*250000;
        offer.fee=revised;
        addNews(`${offer.buyingClub} have increased their offer for ${p.name} to ${money(revised)}.`);
        openIncomingTransferOffer(id);
      }
    }
  }

  if(action==="accept"){
    const oldValue=p.value||fair;
    const oldClub=state.club;
    const buyer=offer.buyingClub;
    const yearsAtClub=(()=>{
      const joined=parseInt(String(p.joined||"").match(/20\d{2}/)?.[0]||"2025",10);
      return Math.max(0,currentSeasonStartYear()-joined);
    })();
    recordStarSale(p,offer.fee,oldValue,yearsAtClub);
    const buyerWage=offer.expectedWage||expectedTransferWage(p,buyer);
    const affordability=aiCanAffordTransfer(buyer,offer.fee,buyerWage);
    if(!affordability.ok){
      offer.status="rejected";
      addNews(`${buyer} withdrew their offer for ${p.name} because they could no longer complete the deal within their financial limits.`);
      closeTransferPlayerFile();
      saveGame(false);
      renderAll();
      return;
    }

    registerManagerSquadVacancy(p,oldClub);
    state.budget+=offer.fee;
    if(state.transferFinance) state.transferFinance.received=(state.transferFinance.received||0)+offer.fee;
    if(state.monthlyFinance) state.monthlyFinance.transferReceived=(state.monthlyFinance.transferReceived||0)+offer.fee;
    applyAITransferPurchase(buyer,offer.fee,buyerWage);
    p.wage=buyerWage;
    transferPlayerToClub(p,buyer,offer.fee,oldClub);
    offer.status="accepted";
    delete state.playerContracts[p.id];
    delete state.playerStats[p.id];
    delete state.playerMorale[p.id];
    delete state.playerListStatus[p.id];
    addNews(`${p.name} has joined ${buyer} from ${oldClub} for ${money(offer.fee)}.`);
    closeTransferPlayerFile();
  }
  saveGame(false);
  renderAll();
}

function runAITransferReview(){
  ensureTransferMarketState();
  const key=typeof currentCalendarWeekKey==="function"?currentCalendarWeekKey():String(state.week);
  if(state.transferReviewsRun[key]) return;
  state.transferReviewsRun[key]=true;

  DB.clubs.filter(c=>c.name!==state.club).forEach(c=>{
    const pressure=aiFinancialPressure(c.name);
    state.aiTransferPlans[c.name]=evaluateSquadNeeds(c.name).slice(0,3).map(n=>({...n,financialPressure:pressure}));
  });
}

function simulateOneAITransfer(){
  ensureTransferMarketState();
  ensureAIClubFinances();
  if(!isTransferWindowOpen()) return;

  const clubs=DB.clubs.filter(c=>c.name!==state.club);
  const buyerPool=clubs.filter(c=>{
    const pressure=aiFinancialPressure(c.name);
    return pressure==="Comfortable" || pressure==="Watch";
  });
  if(!buyerPool.length) return;

  const buyer=buyerPool[Math.floor(Math.random()*buyerPool.length)];
  const needs=state.aiTransferPlans[buyer.name]||evaluateSquadNeeds(buyer.name).slice(0,3);
  const need=needs.find(n=>n.score>=48);
  if(!need) return;

  const targets=findTransferTargets(buyer.name,need.position,10)
    .filter(x=>x.player.club!==state.club)
    .filter(x=>{
      const wage=expectedTransferWage(x.player,buyer.name);
      return aiCanAffordTransfer(buyer.name,x.asking,wage).ok;
    });

  if(!targets.length) return;

  const target=targets[Math.floor(Math.random()*Math.min(3,targets.length))];
  const p=target.player;
  const seller=p.club;
  const sellerOldWage=p.wage||0;
  const newWage=expectedTransferWage(p,buyer.name);
  const fee=Math.round((target.asking*(0.91+Math.random()*.11))/250000)*250000;

  if(!aiCanAffordTransfer(buyer.name,fee,newWage).ok) return;

  applyAITransferPurchase(buyer.name,fee,newWage);
  if(aiFinance(seller)) applyAITransferSale(seller,fee,sellerOldWage);

  p.wage=newWage;
  transferPlayerToClub(p,buyer.name,fee,seller,{kind:"ai"});
  refreshAIClubFinance(buyer.name);
  if(aiFinance(seller)) refreshAIClubFinance(seller);

  if((p.overall||0)>=80 || fee>=35_000_000){
    addNews(`${buyer.name} have signed ${p.name} from ${seller} for ${money(fee)}.`);
  }
}

function processTransferDay(){
  ensureContractState();
  ensureAIClubFinances();

  const windowActive=isTransferWindowOpen();
  if(!windowActive) return;

  // Convert the old weekly probabilities to daily probabilities.
  if(Math.random()<(1-Math.pow(1-0.24,1/7))) generateIncomingOffer();
  if(Math.random()<(1-Math.pow(1-0.34,1/7))) simulateOneAITransfer();
}

function processTransferWeek(){
  // Legacy alias retained for compatibility.
  return processTransferDay();
}

function attachTransferDatabaseDelegation(){
  document.addEventListener("click",e=>{
    const btn=e.target.closest?.(".database-player-link");
    if(btn) openTransferPlayerFile(btn.dataset.playerId);

    const offerBtn=e.target.closest?.(".incoming-offer-btn");
    if(offerBtn) openIncomingTransferOffer(offerBtn.dataset.offerId);
  });
}

document.addEventListener("DOMContentLoaded",attachTransferDatabaseDelegation);


function allAIClubFinanceSnapshots(){
  ensureAIClubFinances();
  return DB.clubs
    .filter(c=>c.name!==state.club)
    .map(c=>aiFinanceSnapshot(c.name))
    .filter(Boolean)
    .sort((a,b)=>b.scrRatio-a.scrRatio);
}


function openManagerShortlist(requestId){
  const req=state.managerRequests?.find(r=>r.id===requestId);
  if(!req||req.type!=="sign") return;
  const shortlist=managerShortlistForRequest(req);
  if(!shortlist.length) return;

  const roleLabel={
    starter:"starting",
    competition:"first-team competition",
    backup:"backup"
  }[req.squadRole] || "";
  q("managerShortlistTitle").textContent=`New ${roleLabel} ${positionLabel(req.position)} shortlist`;
  q("managerShortlistIntro").textContent=`${req.manager} has presented three realistic approaches for this ${roleLabel||"squad"} role.${req.reason?` ${req.reason}`:""}`;
  q("managerShortlistOptions").innerHTML=shortlist.map((x,i)=>{
    const p=x.player, tag=x.role||["Ideal target","Cheaper alternative","Young prospect"][i];
    return `<div class="manager-shortlist-option">
      <div class="manager-shortlist-top">
        <div><span class="shortlist-role">${tag}</span><h3>${p.name}</h3><div class="muted small">${p.club} • ${p.age} yrs • ${p.positions}</div></div>
        <div class="rating">${p.overall}</div>
      </div>
      <div class="shortlist-metrics">
        <div><span>Potential</span><b>${p.potential||p.overall}</b></div>
        <div><span>Est. price</span><b>${money(x.asking||estimatedAskingPrice(p,state.club))}</b></div>
        <div><span>Interest</span><b>${Math.round(x.interest??playerInterestScore(p,state.club))}%</b></div>
      </div>
      <button class="btn ${i===0?"primary":"secondary"} pursue-shortlist-btn" data-request-id="${req.id}" data-player-id="${p.id}" data-role="${tag}">Pursue ${tag.toLowerCase()}</button>
    </div>`;
  }).join("");

  document.querySelectorAll(".pursue-shortlist-btn").forEach(btn=>btn.addEventListener("click",()=>pursueManagerShortlistTarget(btn.dataset.requestId,btn.dataset.playerId,btn.dataset.role)));
  q("managerShortlistModal").classList.remove("hide");
}

function pursueManagerShortlistTarget(requestId,playerId,role){
  const req=state.managerRequests?.find(r=>r.id===requestId);
  const p=DB.players.find(x=>String(x.id)===String(playerId));
  if(!req||!p) return;
  req.resolved=true;
  req.selectedPlayerId=p.id;
  req.selectedRole=role;
  state.managerBacking=clamp((state.managerBacking||70)+(role==="Ideal target"?4:role==="Cheaper alternative"?2:1),0,100);
  addNews(`You selected ${p.name} as the ${role.toLowerCase()} for ${req.manager}'s ${positionLabel(req.position)} request.`);
  q("managerShortlistModal").classList.add("hide");
  saveGame(false);
  openTransferPlayerFile(p.id,{managerRequestId:req.id});
  renderInbox();
  renderDashboard();
}


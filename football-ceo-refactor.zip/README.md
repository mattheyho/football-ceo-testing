# Football CEO — Refactored Test Build

This is the same prototype, reorganised so future features can be developed safely.

## Folder structure

- `index.html` — page structure only
- `css/styles.css` — all visual styling / iPhone layout
- `data/database.js` — clubs and player database
- `js/game.js` — current working gameplay controller
- `js/state.js` — save/state work goes here
- `js/transfers.js` — transfer and contract work goes here
- `js/simulation.js` — match engine / manager / stats work goes here
- `js/staff.js` — staff systems go here
- `js/commercial.js` — pricing / sponsorship / finance work goes here
- `js/stakeholders.js` — happiness systems go here
- `js/ui.js` — UI work goes here

## Important

For this first refactor, the existing working gameplay logic remains in `js/game.js`.
The other JS files are deliberately empty placeholders. This avoids changing gameplay while
we prove that the multi-file deployment works.

From here, each system can be moved out of `game.js` gradually and tested after each move.

## Deploying

Upload the contents of this folder to the root of your GitHub repository, replacing the old
single `index.html`. Netlify should then deploy automatically from GitHub.

Do not upload the ZIP itself as the website root; upload the files/folders inside it.
